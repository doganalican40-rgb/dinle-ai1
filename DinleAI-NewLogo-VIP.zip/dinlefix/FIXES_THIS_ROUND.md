# Bu turda düzeltilenler ve kalan adımlar

## ✅ Şimdi giderdiğim, gerçek rejection riskleri

1. **Sahte "Google ile devam et / Apple ile devam et" butonları kaldırıldı.**
   Bu butonlar hiçbir gerçek girişe bağlı değildi — tıklayınca "bir şey oluyormuş" hissi
   vermeden direkt sonraki ekrana geçiyordu. Play Store bunu "bozuk/yanıltıcı işlevsellik"
   olarak değerlendirebilir. E-posta ve Misafir seçenekleri kaldı çünkü onlar üçüncü taraf
   bir kimlik doğrulaması *iddia etmiyor*.

2. **Sahte "reklam izle" akışı kaldırıldı.**
   Buton bir geri sayım gösterip "reklam oynatılıyor" yazıyordu ama arkasında gerçek bir
   reklam SDK'sı yoktu — hiçbir reklam içeriği gösterilmiyordu. Bu da yanıltıcı işlevsellik
   riski taşıyordu. Şimdi günlük mesaj hakkı bitince dürüst bir "yarın tekrar dene" mesajı
   gösteriliyor. Kod, gerçek bir ödüllü reklam SDK'sı (örn. AdMob) eklendiğinde geri
   getirilebilecek şekilde yorumla işaretlendi.

3. **Gerçekten yayınlanabilir bir Gizlilik Politikası hazırlandı** — `docs/index.html`.
   Kendim bir URL'ye yükleyemem ama bunu **GitHub Pages ile 2 dakikada** canlıya alabilirsin:
   1. Bu projeyi bir GitHub reposuna yükle (zaten `.github/workflows` klasörü var, muhtemelen
      zaten bir reponuz var).
   2. GitHub'da repo → **Settings → Pages** → "Build and deployment" → Source: **Deploy from
      a branch** → Branch: **main**, klasör: **/docs** → Save.
   3. Birkaç dakika sonra `https://KULLANICI_ADIN.github.io/REPO_ADI/` adresinde canlı olur.
   4. `docs/index.html` içindeki **[E-POSTA ADRESİNİZİ BURAYA YAZIN]** yerlerini doldurmayı
      unutma — bunlar Play Console'un istediği gerçek iletişim bilgisi.
   5. Bu URL'yi Play Console'daki "Gizlilik Politikası" alanına yapıştır.

## ⚠️ Benim çözemediğim, sizin yapmanız gereken şeyler

- **Backend URL hâlâ placeholder** (`YOUR-BACKEND-URL`) — gerçek bir sunucuya (kendi OpenAI/Anthropic
  API anahtarınızla) deploy edip `.env`'e yazmanız gerekiyor. Kod tarafı zaten hazır ve bağlantı
  koparsa uygulama çökmüyor, sadece "bağlantı sorunu" mesajı gösteriyor — ama gerçek kullanım için
  çalışan bir backend şart.
- **Gerçek Google/Apple girişi** — Google Cloud'da kendi OAuth Client ID'nizi oluşturup bana
  verirseniz, deep-link + sistem tarayıcısı akışını o zaman kurarım.
- **Gerçek reklam SDK'sı** — AdMob hesabı açıp bir Ad Unit ID oluşturursanız entegre ederim.
- **Play Console'un Veri Güvenliği formu, mağaza görselleri, yaş derecelendirme anketi** — bunlar
  kod değil, Play Console arayüzünde elle doldurulan formlar.

## Not
`startAd`, `adPlaying`, `adSeconds` gibi artık kullanılmayan birkaç değişken dosyada duruyor
(zararsız, derlemeyi bozmaz) — ileride gerçek reklam SDK'sı eklerken oraya bağlanabilirler,
o yüzden şimdilik silmedim.

## 2026-08-17 — Human-like AI video call
- Replaced the simple circular robot face in the call screen with a generic human-like synthetic AI avatar.
- Added animated blinking and mouth movement while the AI is speaking.
- Added a live AI badge, video-call frame, scanline effect, and clearer call status.
- The call now starts with the selected AI's greeting using the existing speech synthesis.
- Camera can now be turned on/off cleanly and its media track is stopped when the call closes.
- Android camera/microphone permissions were already present in the project and remain enabled.

## 2026-08-17 — New Dinle AI VIP Logo
- Replaced the previous ear/soundwave mark with the new dark + gold VIP identity.
- The in-app `LogoMark` now uses a gold D, crown, purple/gold ring and subtle glow.
- Android launcher foreground/background vectors were updated to match the new identity.
- App display name updated to `Dinle • AI`.
