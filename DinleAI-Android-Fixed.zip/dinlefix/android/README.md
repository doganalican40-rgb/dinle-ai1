# Dinle AI Android

Android Studio'da bu klasörü aç. SDK 35 ve JDK 17+ kurulu olmalı. Gradle Sync yapıp `app` konfigürasyonundan APK üretilebilir.
