import React, { useState, useRef, useEffect } from "react";

// --- Supported languages ---
const LANGUAGES = [
  { code: "tr", label: "Türkçe", speechLang: "tr-TR", rtl: false, clinicQuery: "psikolog ruh sağlığı kliniği" },
  { code: "en", label: "English", speechLang: "en-US", rtl: false, clinicQuery: "psychologist mental health clinic" },
  { code: "es", label: "Español", speechLang: "es-ES", rtl: false, clinicQuery: "psicólogo clínica de salud mental" },
  { code: "de", label: "Deutsch", speechLang: "de-DE", rtl: false, clinicQuery: "Psychologe psychische Gesundheit Klinik" },
  { code: "fr", label: "Français", speechLang: "fr-FR", rtl: false, clinicQuery: "psychologue clinique de santé mentale" },
  { code: "ar", label: "العربية", speechLang: "ar-SA", rtl: true, clinicQuery: "طبيب نفسي عيادة صحة نفسية" },
];

const LANG_NAME_FOR_MODEL = {
  tr: "Turkish", en: "English", es: "Spanish", de: "German", fr: "French", ar: "Arabic",
};

// Country -> app language, used for location-based auto-detection on first launch
const COUNTRY_TO_LANG = {
  TR: "tr",
  US: "en", GB: "en", AU: "en", CA: "en", IE: "en", NZ: "en", ZA: "en", IN: "en",
  ES: "es", MX: "es", AR: "es", CO: "es", CL: "es", PE: "es",
  DE: "de", AT: "de", CH: "de",
  FR: "fr", BE: "fr",
  SA: "ar", AE: "ar", EG: "ar", QA: "ar", KW: "ar", MA: "ar", DZ: "ar", TN: "ar", JO: "ar", IQ: "ar", LB: "ar",
};

// --- Onboarding: name, age, and 10 short optional getting-to-know-you questions ---
const OB = {
  tr: {
    title: "Seni tanıyalım", subtitle: "Sana daha iyi eşlik edebilmemiz için birkaç soru soracağız. Her soru isteğe bağlı, dilediğin an atlayabilirsin.",
    start: "Başla", skipAll: "Tümünü atla, sohbete geç", next: "İleri", back: "Geri", skip: "Bu soruyu atla", finish: "Sohbete başla",
    nameQ: "Sana nasıl hitap edelim?", namePh: "İsmin (opsiyonel)",
    ageQ: "Kaç yaşındasın?", agePh: "Yaşın (opsiyonel)",
    questions: [
      { type: "choice", q: "Bugün buraya gelme sebebin ne?", options: ["Konuşacak biri istiyorum", "Zor bir gün geçiriyorum", "Sadece sohbet etmek istiyorum", "Meraktan bakıyorum"] },
      { type: "choice", q: "Şu sıralar kendini nasıl hissediyorsun?", options: ["İyi", "Orta", "Zorlanıyorum", "Söylemek istemiyorum"] },
      { type: "text", q: "Ne iş yapıyorsun ya da okuyor musun?", ph: "İstersen yaz…" },
      { type: "choice", q: "Bir şey seni zorladığında genelde kiminle konuşursun?", options: ["Ailem", "Arkadaşlarım", "Kimseyle konuşmam", "Değişir"] },
      { type: "text", q: "Seni rahatlatan bir şey var mı?", ph: "Müzik, yürüyüş, ne olursa…" },
      { type: "choice", q: "Kendini daha çok nasıl tanımlarsın?", options: ["İçe dönük", "Dışa dönük", "İkisi de biraz"] },
      { type: "choice", q: "Benden ne bekliyorsun?", options: ["Sadece dinlememi", "Tavsiye vermemi", "Dikkatimi dağıtmamı", "Henüz bilmiyorum"] },
      { type: "text", q: "Şu anda hayatında seni mutlu eden bir şey var mı?", ph: "İstersen paylaş…" },
      { type: "choice", q: "Genelde günün hangi saatinde konuşmak istersin?", options: ["Sabah", "Öğlen", "Akşam", "Gece", "Değişir"] },
      { type: "text", q: "Bugünlerde beklediğin bir şey var mı?", ph: "İstersen yaz…" },
      { type: "choice", q: "Bugün en çok neyle ilgili yardım istersin?", topicQuestion: true,
        options: ["Sadece konuşmak istiyorum", "Borç/Finans konusunda yardım", "İş fikirleri bulmak istiyorum", "Büyük bir sorunumu çözmek istiyorum"] },
    ],
  },
  en: {
    title: "Let's get to know you", subtitle: "We'll ask a few short questions so we can be a better listener. Every question is optional — skip any time.",
    start: "Start", skipAll: "Skip all, go to chat", next: "Next", back: "Back", skip: "Skip this question", finish: "Start chatting",
    nameQ: "What should we call you?", namePh: "Your name (optional)",
    ageQ: "How old are you?", agePh: "Your age (optional)",
    questions: [
      { type: "choice", q: "What brings you here today?", options: ["I want someone to talk to", "I'm having a hard day", "Just want to chat", "Just curious"] },
      { type: "choice", q: "How have you been feeling lately?", options: ["Good", "Okay", "Struggling", "Prefer not to say"] },
      { type: "text", q: "What do you do, or are you studying?", ph: "Feel free to share…" },
      { type: "choice", q: "Who do you usually talk to when something's bothering you?", options: ["My family", "My friends", "I don't really talk to anyone", "It varies"] },
      { type: "text", q: "Is there anything that helps you relax?", ph: "Music, walking, anything…" },
      { type: "choice", q: "How would you describe yourself?", options: ["Introverted", "Extroverted", "A bit of both"] },
      { type: "choice", q: "What are you hoping for from our chats?", options: ["Just to listen", "To offer advice", "A distraction", "Not sure yet"] },
      { type: "text", q: "Is there anything in your life right now that makes you happy?", ph: "Share if you'd like…" },
      { type: "choice", q: "What time of day do you usually prefer to talk?", options: ["Morning", "Afternoon", "Evening", "Night", "It varies"] },
      { type: "text", q: "Is there anything you're looking forward to these days?", ph: "Feel free to share…" },
      { type: "choice", q: "What would you like help with today?", topicQuestion: true,
        options: ["I just want to talk", "Help with debt/finance", "I want business ideas", "I want to work through a big problem"] },
    ],
  },
  es: {
    title: "Conozcámonos", subtitle: "Te haremos algunas preguntas breves para poder acompañarte mejor. Cada pregunta es opcional, puedes omitirla cuando quieras.",
    start: "Comenzar", skipAll: "Omitir todo, ir al chat", next: "Siguiente", back: "Atrás", skip: "Omitir esta pregunta", finish: "Empezar a chatear",
    nameQ: "¿Cómo te llamamos?", namePh: "Tu nombre (opcional)",
    ageQ: "¿Cuántos años tienes?", agePh: "Tu edad (opcional)",
    questions: [
      { type: "choice", q: "¿Qué te trae por aquí hoy?", options: ["Quiero hablar con alguien", "Estoy teniendo un día difícil", "Solo quiero charlar", "Solo tengo curiosidad"] },
      { type: "choice", q: "¿Cómo te has sentido últimamente?", options: ["Bien", "Más o menos", "Con dificultades", "Prefiero no decirlo"] },
      { type: "text", q: "¿A qué te dedicas o estudias?", ph: "Cuéntame si quieres…" },
      { type: "choice", q: "¿Con quién sueles hablar cuando algo te preocupa?", options: ["Mi familia", "Mis amigos", "No suelo hablar con nadie", "Depende"] },
      { type: "text", q: "¿Hay algo que te ayude a relajarte?", ph: "Música, caminar, lo que sea…" },
      { type: "choice", q: "¿Cómo te describirías?", options: ["Introvertido/a", "Extrovertido/a", "Un poco de ambos"] },
      { type: "choice", q: "¿Qué esperas de nuestras conversaciones?", options: ["Que solo escuche", "Que dé consejos", "Una distracción", "Aún no lo sé"] },
      { type: "text", q: "¿Hay algo en tu vida ahora mismo que te haga feliz?", ph: "Comparte si quieres…" },
      { type: "choice", q: "¿En qué momento del día prefieres hablar?", options: ["Mañana", "Tarde", "Noche temprana", "Noche", "Depende"] },
      { type: "text", q: "¿Hay algo que estés esperando con ganas estos días?", ph: "Cuéntame si quieres…" },
      { type: "choice", q: "¿Con qué te gustaría que te ayudara hoy?", topicQuestion: true,
        options: ["Solo quiero hablar", "Ayuda con deudas/finanzas", "Quiero ideas de negocio", "Quiero resolver un gran problema"] },
    ],
  },
  de: {
    title: "Lernen wir dich kennen", subtitle: "Wir stellen dir ein paar kurze Fragen, damit wir dir besser zuhören können. Jede Frage ist freiwillig — du kannst jederzeit überspringen.",
    start: "Starten", skipAll: "Alles überspringen, zum Chat", next: "Weiter", back: "Zurück", skip: "Diese Frage überspringen", finish: "Chat starten",
    nameQ: "Wie sollen wir dich nennen?", namePh: "Dein Name (optional)",
    ageQ: "Wie alt bist du?", agePh: "Dein Alter (optional)",
    questions: [
      { type: "choice", q: "Was führt dich heute hierher?", options: ["Ich möchte mit jemandem reden", "Ich habe einen schwierigen Tag", "Ich möchte einfach plaudern", "Nur aus Neugier"] },
      { type: "choice", q: "Wie fühlst du dich in letzter Zeit?", options: ["Gut", "So la la", "Ich kämpfe gerade", "Möchte ich nicht sagen"] },
      { type: "text", q: "Was machst du beruflich oder studierst du?", ph: "Erzähl es mir, wenn du magst…" },
      { type: "choice", q: "Mit wem sprichst du normalerweise, wenn dich etwas beschäftigt?", options: ["Meiner Familie", "Meinen Freunden", "Mit niemandem", "Kommt drauf an"] },
      { type: "text", q: "Gibt es etwas, das dir hilft zu entspannen?", ph: "Musik, Spazierengehen, was auch immer…" },
      { type: "choice", q: "Wie würdest du dich beschreiben?", options: ["Introvertiert", "Extrovertiert", "Etwas von beidem"] },
      { type: "choice", q: "Was erhoffst du dir von unseren Gesprächen?", options: ["Einfach zuhören", "Ratschläge geben", "Eine Ablenkung", "Noch nicht sicher"] },
      { type: "text", q: "Gibt es gerade etwas in deinem Leben, das dich glücklich macht?", ph: "Erzähl es, wenn du magst…" },
      { type: "choice", q: "Zu welcher Tageszeit sprichst du am liebsten?", options: ["Morgens", "Mittags", "Abends", "Nachts", "Kommt drauf an"] },
      { type: "text", q: "Gibt es momentan etwas, worauf du dich freust?", ph: "Erzähl es, wenn du magst…" },
      { type: "choice", q: "Wobei möchtest du heute Hilfe?", topicQuestion: true,
        options: ["Ich möchte einfach reden", "Hilfe bei Schulden/Finanzen", "Ich möchte Geschäftsideen", "Ich möchte ein großes Problem lösen"] },
    ],
  },
  fr: {
    title: "Faisons connaissance", subtitle: "On va te poser quelques questions courtes pour mieux t'accompagner. Chaque question est facultative — tu peux passer à tout moment.",
    start: "Commencer", skipAll: "Tout ignorer, aller au chat", next: "Suivant", back: "Précédent", skip: "Ignorer cette question", finish: "Commencer à discuter",
    nameQ: "Comment doit-on t'appeler ?", namePh: "Ton prénom (facultatif)",
    ageQ: "Quel âge as-tu ?", agePh: "Ton âge (facultatif)",
    questions: [
      { type: "choice", q: "Qu'est-ce qui t'amène ici aujourd'hui ?", options: ["Je veux parler à quelqu'un", "Je passe une journée difficile", "Je veux juste discuter", "Par curiosité"] },
      { type: "choice", q: "Comment te sens-tu ces derniers temps ?", options: ["Bien", "Moyen", "Je traverse une période difficile", "Je préfère ne pas le dire"] },
      { type: "text", q: "Que fais-tu dans la vie, ou étudies-tu ?", ph: "Dis-le-moi si tu veux…" },
      { type: "choice", q: "À qui parles-tu habituellement quand quelque chose te tracasse ?", options: ["Ma famille", "Mes amis", "Je ne parle à personne", "Ça dépend"] },
      { type: "text", q: "Y a-t-il quelque chose qui t'aide à te détendre ?", ph: "Musique, marche, n'importe quoi…" },
      { type: "choice", q: "Comment te décrirais-tu ?", options: ["Introverti(e)", "Extraverti(e)", "Un peu des deux"] },
      { type: "choice", q: "Qu'attends-tu de nos échanges ?", options: ["Juste écouter", "Donner des conseils", "Une distraction", "Je ne sais pas encore"] },
      { type: "text", q: "Y a-t-il quelque chose dans ta vie en ce moment qui te rend heureux/heureuse ?", ph: "Partage si tu veux…" },
      { type: "choice", q: "À quel moment de la journée préfères-tu parler ?", options: ["Matin", "Après-midi", "Soir", "Nuit", "Ça dépend"] },
      { type: "text", q: "Y a-t-il quelque chose que tu attends avec impatience ces jours-ci ?", ph: "Partage si tu veux…" },
      { type: "choice", q: "Avec quoi aimerais-tu de l'aide aujourd'hui ?", topicQuestion: true,
        options: ["Je veux juste parler", "Aide pour dettes/finances", "Je veux des idées d'entreprise", "Je veux résoudre un grand problème"] },
    ],
  },
  ar: {
    title: "لنتعرف عليك", subtitle: "سنطرح عليك بضعة أسئلة قصيرة لنتمكن من الإصغاء إليك بشكل أفضل. كل سؤال اختياري ويمكنك تخطيه في أي وقت.",
    start: "ابدأ", skipAll: "تخطي الكل والانتقال للدردشة", next: "التالي", back: "رجوع", skip: "تخطي هذا السؤال", finish: "ابدأ الدردشة",
    nameQ: "بماذا ننادينك؟", namePh: "اسمك (اختياري)",
    ageQ: "كم عمرك؟", agePh: "عمرك (اختياري)",
    questions: [
      { type: "choice", q: "ما الذي أتى بك إلى هنا اليوم؟", options: ["أريد التحدث مع أحد", "أمر بيوم صعب", "أريد الدردشة فقط", "من باب الفضول"] },
      { type: "choice", q: "كيف تشعر مؤخرًا؟", options: ["بخير", "لا بأس", "أواجه صعوبة", "أفضل عدم القول"] },
      { type: "text", q: "ما عملك أو هل أنت طالب؟", ph: "شاركني إن أحببت…" },
      { type: "choice", q: "مع من تتحدث عادة عندما يزعجك شيء؟", options: ["عائلتي", "أصدقائي", "لا أتحدث مع أحد", "يختلف"] },
      { type: "text", q: "هل هناك ما يساعدك على الاسترخاء؟", ph: "موسيقى، مشي، أي شيء…" },
      { type: "choice", q: "كيف تصف نفسك؟", options: ["انطوائي", "اجتماعي", "مزيج من الاثنين"] },
      { type: "choice", q: "ما الذي تتمناه من محادثاتنا؟", options: ["الاستماع فقط", "تقديم النصائح", "تشتيت الانتباه", "لست متأكدًا بعد"] },
      { type: "text", q: "هل هناك شيء في حياتك الآن يسعدك؟", ph: "شاركني إن أحببت…" },
      { type: "choice", q: "في أي وقت من اليوم تفضل التحدث عادة؟", options: ["الصباح", "الظهيرة", "المساء", "الليل", "يختلف"] },
      { type: "text", q: "هل هناك شيء تتطلع إليه هذه الأيام؟", ph: "شاركني إن أحببت…" },
      { type: "choice", q: "بماذا تحب أن أساعدك اليوم؟", topicQuestion: true,
        options: ["أريد التحدث فقط", "مساعدة في الديون/المالية", "أريد أفكارًا تجارية", "أريد حل مشكلة كبيرة"] },
    ],
  },
};

// --- Crisis / concern keyword detection per language ---
const CRISIS_PATTERNS = {
  tr: ["intihar", "kendimi öldür", "kendime zarar", "yaşamak istemiyorum", "ölmek istiyorum", "canıma kıy", "bıçakla kendimi", "artık dayanamıyorum", "hayatıma son", "kendimi kes"],
  en: ["suicide", "kill myself", "end my life", "want to die", "hurt myself", "self harm", "cutting myself", "can't go on", "no reason to live"],
  es: ["suicidio", "quitarme la vida", "matarme", "no quiero vivir", "hacerme daño", "autolesionarme", "no puedo más", "acabar con todo"],
  de: ["suizid", "mich umbringen", "selbstmord", "ich will nicht mehr leben", "mir selbst schaden", "ich kann nicht mehr", "mein leben beenden"],
  fr: ["suicide", "me suicider", "en finir", "je veux mourir", "me faire du mal", "je n'en peux plus", "mettre fin à mes jours"],
  ar: ["انتحار", "أقتل نفسي", "أنهي حياتي", "أريد أن أموت", "أؤذي نفسي", "لا أستطيع الاستمرار"],
};

const CONCERN_PATTERNS = {
  tr: ["panik atak", "depresyondayım", "çok kötü hissediyorum", "uyuyamıyorum", "kendimi çok kötü", "tükendim", "boşluk hissediyorum", "kimsem yok", "değersiz hissediyorum", "anksiyetem"],
  en: ["panic attack", "i'm depressed", "feel really bad", "can't sleep", "i feel worthless", "burned out", "burnt out", "i feel empty", "i have no one", "my anxiety"],
  es: ["ataque de pánico", "estoy deprimido", "me siento muy mal", "no puedo dormir", "me siento sin valor", "estoy agotado", "me siento vacío", "no tengo a nadie", "mi ansiedad"],
  de: ["panikattacke", "ich bin depressiv", "fühle mich schrecklich", "kann nicht schlafen", "ich fühle mich wertlos", "bin ausgebrannt", "ich fühle mich leer", "ich habe niemanden", "meine angst"],
  fr: ["crise de panique", "je suis déprimé", "je me sens très mal", "je n'arrive pas à dormir", "je me sens sans valeur", "épuisé", "je me sens vide", "je n'ai personne", "mon anxiété"],
  ar: ["نوبة هلع", "أشعر بالاكتئاب", "أشعر بسوء شديد", "لا أستطيع النوم", "أشعر بلا قيمة", "منهك", "أشعر بالفراغ", "ليس لدي أحد", "قلقي"],
};

const LOCALE_FOR_LANG = { tr: "tr-TR", en: "en-US", es: "es-ES", de: "de-DE", fr: "fr-FR", ar: "ar-SA" };

function detectLevel(text, langCode) {
  const lower = text.toLocaleLowerCase(LOCALE_FOR_LANG[langCode] || "en-US");
  const crisis = CRISIS_PATTERNS[langCode] || CRISIS_PATTERNS.en;
  const concern = CONCERN_PATTERNS[langCode] || CONCERN_PATTERNS.en;
  if (crisis.some((p) => lower.includes(p))) return "crisis";
  if (concern.some((p) => lower.includes(p))) return "concern";
  return "none";
}

// --- UI strings per language ---
const UI = {
  tr: {
    greeting: "Merhaba. Buradayım, dinliyorum. İçinden geleni, hazır olduğunda paylaşabilirsin.",
    disclaimer: "Dinle bir terapist değildir ve profesyonel destek yerine geçmez.",
    placeholder: "Aklından geçeni yaz ya da mikrofona konuş…",
    idle: "seni duyan bir yer", listening: "seni dinliyor…", thinking: "düşünüyor…", speaking: "konuşuyor…",
    crisisTitle: "Yalnız değilsin",
    crisisText: "Bu anda zorlanıyor gibisin. Lütfen hemen konuşabileceğin biriyle iletişime geç:",
    crisisHotline: "Acil durum numaranı ara, ya da ülkendeki bir kriz hattını ara. Türkiye: 182 (Sosyal Destek) / 112 (Acil).",
    clinicBtn: "En yakın kliniği göster", closeBtn: "Kapat",
    concernTitle: "Zor bir dönemden mi geçiyorsun?",
    concernText: "Bunu bir uzmanla konuşmak fark yaratabilir. İstersen sana yakın bir yer bulayım.",
    concernBtn: "Yakınımdaki uzmanı bul", concernBtn2: "Şimdi değil",
    voiceLabel: "Ses", femaleLabel: "Kadın", maleLabel: "Erkek",
    replyLabel: "Yanıt", fastLabel: "Hızlı", balancedLabel: "Orta", deepLabel: "Derin",
    langLabel: "Dil",
    micTitleOn: "Sesle konuş", micTitleOff: "Bu tarayıcıda sesli giriş desteklenmiyor",
    voiceToggleTitle: "Sesli okumayı aç/kapat",
    voicesLoading: "Cihazının sesleri yükleniyor… yoksa varsayılan ses kullanılır.",
    topicLabel: "Konu", topicGeneral: "Genel", topicDebt: "Borç/Finans",
    topicBusiness: "İş Fikirleri", topicBig: "Büyük Sorunlar",
    financialDisclaimer: "Bu genel bilgilendirmedir, finansal tavsiye değildir; lisanslı bir danışman değilim.",
    connError: "Bağlantıda bir sorun oldu. Biraz sonra tekrar dener misin?",
    freeRemaining: "Bugün kalan ücretsiz mesaj", adGateTitle: "Ücretsiz mesaj hakkın bitti",
    adGateText: "Kısa bir reklam izleyerek {n} mesaj daha kazanabilirsin.",
    watchAdBtn: "Reklam izle ve devam et", adPlaying: "Reklam oynatılıyor…",
    adDoneToast: "Teşekkürler! {n} mesaj daha kazandın.", noMoreAdsText: "Bugünkü reklam hakkın doldu, yarın tekrar dene.",
    signinTitle: "Dinle'ye hoş geldin", signinSubtitle: "Devam etmek için bir seçenek belirle.",
    signinGoogle: "Google ile devam et", signinApple: "Apple ile devam et", signinEmail: "E-posta ile devam et",
    signinGuest: "Misafir olarak devam et", emailPh: "E-posta adresin", emailContinue: "Devam et",
  },
  en: {
    greeting: "Hi. I'm here, listening. Share whatever's on your mind, whenever you're ready.",
    disclaimer: "Dinle is not a therapist and isn't a substitute for professional support.",
    placeholder: "Type what's on your mind, or speak into the mic…",
    idle: "a place that hears you", listening: "listening to you…", thinking: "thinking…", speaking: "speaking…",
    crisisTitle: "You're not alone",
    crisisText: "It sounds like you're struggling right now. Please reach out to someone you can talk to immediately:",
    crisisHotline: "Call your local emergency number, or search for a crisis line in your country. In the US: call or text 988.",
    clinicBtn: "Show nearest clinic", closeBtn: "Close",
    concernTitle: "Going through a hard time?",
    concernText: "Talking to a professional could really help. I can help you find someone nearby if you'd like.",
    concernBtn: "Find help nearby", concernBtn2: "Not now",
    voiceLabel: "Voice", femaleLabel: "Female", maleLabel: "Male",
    replyLabel: "Reply", fastLabel: "Fast", balancedLabel: "Balanced", deepLabel: "Deep",
    langLabel: "Language",
    micTitleOn: "Speak", micTitleOff: "Voice input isn't supported in this browser",
    voiceToggleTitle: "Toggle voice reply",
    voicesLoading: "Loading voices on your device… a default voice will be used otherwise.",
    topicLabel: "Topic", topicGeneral: "General", topicDebt: "Debt/Finance",
    topicBusiness: "Business Ideas", topicBig: "Big Problems",
    financialDisclaimer: "This is general information, not financial advice; I'm not a licensed advisor.",
    connError: "There was a connection issue. Could you try again in a moment?",
    freeRemaining: "Free messages left today", adGateTitle: "You're out of free messages",
    adGateText: "Watch a short ad to earn {n} more messages.",
    watchAdBtn: "Watch ad to continue", adPlaying: "Playing ad…",
    adDoneToast: "Thanks! You earned {n} more messages.", noMoreAdsText: "You've reached today's ad limit — try again tomorrow.",
    signinTitle: "Welcome to Dinle", signinSubtitle: "Choose an option to continue.",
    signinGoogle: "Continue with Google", signinApple: "Continue with Apple", signinEmail: "Continue with email",
    signinGuest: "Continue as guest", emailPh: "Your email address", emailContinue: "Continue",
  },
  es: {
    greeting: "Hola. Estoy aquí, escuchando. Comparte lo que tengas en mente cuando estés listo o lista.",
    disclaimer: "Dinle no es un terapeuta y no sustituye el apoyo profesional.",
    placeholder: "Escribe lo que piensas o habla por el micrófono…",
    idle: "un lugar que te escucha", listening: "te está escuchando…", thinking: "pensando…", speaking: "hablando…",
    crisisTitle: "No estás solo o sola",
    crisisText: "Parece que estás pasando por un momento difícil. Por favor contacta ahora mismo a alguien con quien puedas hablar:",
    crisisHotline: "Llama al número de emergencias de tu país, o busca una línea de crisis local.",
    clinicBtn: "Mostrar clínica más cercana", closeBtn: "Cerrar",
    concernTitle: "¿Estás pasando por un momento difícil?",
    concernText: "Hablar con un profesional puede ayudar mucho. Puedo ayudarte a encontrar a alguien cercano si quieres.",
    concernBtn: "Buscar ayuda cercana", concernBtn2: "Ahora no",
    voiceLabel: "Voz", femaleLabel: "Femenina", maleLabel: "Masculina",
    replyLabel: "Respuesta", fastLabel: "Rápida", balancedLabel: "Media", deepLabel: "Profunda",
    langLabel: "Idioma",
    micTitleOn: "Hablar", micTitleOff: "La entrada de voz no es compatible con este navegador",
    voiceToggleTitle: "Activar o desactivar la voz",
    voicesLoading: "Cargando voces de tu dispositivo… si no, se usará una voz predeterminada.",
    topicLabel: "Tema", topicGeneral: "General", topicDebt: "Deudas/Finanzas",
    topicBusiness: "Ideas de negocio", topicBig: "Grandes problemas",
    financialDisclaimer: "Esto es información general, no es asesoría financiera; no soy un asesor con licencia.",
    connError: "Hubo un problema de conexión. ¿Puedes intentarlo de nuevo en un momento?",
    freeRemaining: "Mensajes gratis restantes hoy", adGateTitle: "Se acabaron tus mensajes gratis",
    adGateText: "Mira un anuncio corto para ganar {n} mensajes más.",
    watchAdBtn: "Ver anuncio para continuar", adPlaying: "Reproduciendo anuncio…",
    adDoneToast: "¡Gracias! Ganaste {n} mensajes más.", noMoreAdsText: "Alcanzaste el límite de anuncios de hoy, inténtalo mañana.",
    signinTitle: "Bienvenido a Dinle", signinSubtitle: "Elige una opción para continuar.",
    signinGoogle: "Continuar con Google", signinApple: "Continuar con Apple", signinEmail: "Continuar con correo",
    signinGuest: "Continuar como invitado", emailPh: "Tu correo electrónico", emailContinue: "Continuar",
  },
  de: {
    greeting: "Hallo. Ich bin hier und höre zu. Teile, was dich beschäftigt, wann immer du bereit bist.",
    disclaimer: "Dinle ist kein Therapeut und ersetzt keine professionelle Unterstützung.",
    placeholder: "Schreib, was dich beschäftigt, oder sprich ins Mikrofon…",
    idle: "ein Ort, der dich hört", listening: "hört dir zu…", thinking: "denkt nach…", speaking: "spricht…",
    crisisTitle: "Du bist nicht allein",
    crisisText: "Es klingt, als hättest du es gerade schwer. Bitte wende dich sofort an jemanden, mit dem du sprechen kannst:",
    crisisHotline: "Ruf deinen lokalen Notruf an oder suche nach einer Krisenhotline in deinem Land. In der EU: 112.",
    clinicBtn: "Nächste Klinik anzeigen", closeBtn: "Schließen",
    concernTitle: "Machst du gerade eine schwere Zeit durch?",
    concernText: "Mit einer Fachperson zu sprechen kann wirklich helfen. Ich kann dir helfen, jemanden in deiner Nähe zu finden.",
    concernBtn: "Hilfe in der Nähe finden", concernBtn2: "Jetzt nicht",
    voiceLabel: "Stimme", femaleLabel: "Weiblich", maleLabel: "Männlich",
    replyLabel: "Antwort", fastLabel: "Schnell", balancedLabel: "Ausgewogen", deepLabel: "Tief",
    langLabel: "Sprache",
    micTitleOn: "Sprechen", micTitleOff: "Spracheingabe wird in diesem Browser nicht unterstützt",
    voiceToggleTitle: "Sprachausgabe ein/aus",
    voicesLoading: "Stimmen deines Geräts werden geladen… sonst wird eine Standardstimme verwendet.",
    topicLabel: "Thema", topicGeneral: "Allgemein", topicDebt: "Schulden/Finanzen",
    topicBusiness: "Geschäftsideen", topicBig: "Große Probleme",
    financialDisclaimer: "Das sind allgemeine Informationen, keine Finanzberatung; ich bin kein zugelassener Berater.",
    connError: "Es gab ein Verbindungsproblem. Kannst du es gleich noch einmal versuchen?",
    freeRemaining: "Verbleibende kostenlose Nachrichten heute", adGateTitle: "Deine kostenlosen Nachrichten sind aufgebraucht",
    adGateText: "Sieh dir eine kurze Werbung an, um {n} weitere Nachrichten zu erhalten.",
    watchAdBtn: "Werbung ansehen und fortfahren", adPlaying: "Werbung wird abgespielt…",
    adDoneToast: "Danke! Du hast {n} weitere Nachrichten erhalten.", noMoreAdsText: "Du hast dein heutiges Werbelimit erreicht — versuch es morgen erneut.",
    signinTitle: "Willkommen bei Dinle", signinSubtitle: "Wähle eine Option, um fortzufahren.",
    signinGoogle: "Mit Google fortfahren", signinApple: "Mit Apple fortfahren", signinEmail: "Mit E-Mail fortfahren",
    signinGuest: "Als Gast fortfahren", emailPh: "Deine E-Mail-Adresse", emailContinue: "Weiter",
  },
  fr: {
    greeting: "Bonjour. Je suis là, à l'écoute. Partage ce qui te préoccupe quand tu seras prêt ou prête.",
    disclaimer: "Dinle n'est pas un thérapeute et ne remplace pas un accompagnement professionnel.",
    placeholder: "Écris ce que tu penses ou parle dans le micro…",
    idle: "un endroit qui t'écoute", listening: "t'écoute…", thinking: "réfléchit…", speaking: "parle…",
    crisisTitle: "Tu n'es pas seul(e)",
    crisisText: "On dirait que tu traverses un moment difficile. Contacte immédiatement quelqu'un à qui parler :",
    crisisHotline: "Appelle le numéro d'urgence de ton pays, ou cherche une ligne d'écoute locale. En Europe : 112.",
    clinicBtn: "Afficher la clinique la plus proche", closeBtn: "Fermer",
    concernTitle: "Tu traverses une période difficile ?",
    concernText: "Parler à un professionnel peut vraiment aider. Je peux t'aider à trouver quelqu'un près de toi.",
    concernBtn: "Trouver de l'aide à proximité", concernBtn2: "Pas maintenant",
    voiceLabel: "Voix", femaleLabel: "Féminine", maleLabel: "Masculine",
    replyLabel: "Réponse", fastLabel: "Rapide", balancedLabel: "Équilibrée", deepLabel: "Approfondie",
    langLabel: "Langue",
    micTitleOn: "Parler", micTitleOff: "La saisie vocale n'est pas prise en charge par ce navigateur",
    voiceToggleTitle: "Activer/désactiver la lecture vocale",
    voicesLoading: "Chargement des voix de ton appareil… sinon une voix par défaut sera utilisée.",
    topicLabel: "Sujet", topicGeneral: "Général", topicDebt: "Dettes/Finances",
    topicBusiness: "Idées d'entreprise", topicBig: "Grands problèmes",
    financialDisclaimer: "Ceci est une information générale, pas un conseil financier ; je ne suis pas conseiller agréé.",
    connError: "Un problème de connexion est survenu. Peux-tu réessayer dans un instant ?",
    freeRemaining: "Messages gratuits restants aujourd'hui", adGateTitle: "Tu as utilisé tous tes messages gratuits",
    adGateText: "Regarde une courte pub pour gagner {n} messages de plus.",
    watchAdBtn: "Regarder une pub pour continuer", adPlaying: "Lecture de la publicité…",
    adDoneToast: "Merci ! Tu as gagné {n} messages de plus.", noMoreAdsText: "Tu as atteint la limite de pubs du jour — réessaie demain.",
    signinTitle: "Bienvenue sur Dinle", signinSubtitle: "Choisis une option pour continuer.",
    signinGoogle: "Continuer avec Google", signinApple: "Continuer avec Apple", signinEmail: "Continuer avec un e-mail",
    signinGuest: "Continuer en tant qu'invité", emailPh: "Ton adresse e-mail", emailContinue: "Continuer",
  },
  ar: {
    greeting: "مرحبًا. أنا هنا، أستمع إليك. شارك ما يدور في ذهنك عندما تكون مستعدًا.",
    disclaimer: "دِينلِه ليس معالجًا نفسيًا ولا يغني عن الدعم المتخصص.",
    placeholder: "اكتب ما يدور في ذهنك أو تحدث عبر الميكروفون…",
    idle: "مكان يسمعك", listening: "يستمع إليك…", thinking: "يفكر…", speaking: "يتحدث…",
    crisisTitle: "لست وحدك",
    crisisText: "يبدو أنك تمر بوقت صعب الآن. من فضلك تواصل فورًا مع شخص يمكنك التحدث إليه:",
    crisisHotline: "اتصل برقم الطوارئ في بلدك، أو ابحث عن خط أزمات محلي.",
    clinicBtn: "عرض أقرب عيادة", closeBtn: "إغلاق",
    concernTitle: "هل تمر بوقت عصيب؟",
    concernText: "التحدث مع مختص قد يساعد كثيرًا. يمكنني مساعدتك في إيجاد شخص قريب منك.",
    concernBtn: "البحث عن مساعدة قريبة", concernBtn2: "ليس الآن",
    voiceLabel: "الصوت", femaleLabel: "أنثى", maleLabel: "ذكر",
    replyLabel: "الرد", fastLabel: "سريع", balancedLabel: "متوازن", deepLabel: "عميق",
    langLabel: "اللغة",
    micTitleOn: "تحدث", micTitleOff: "الإدخال الصوتي غير مدعوم في هذا المتصفح",
    voiceToggleTitle: "تشغيل/إيقاف القراءة الصوتية",
    voicesLoading: "جاري تحميل أصوات جهازك… وإلا سيُستخدم صوت افتراضي.",
    topicLabel: "الموضوع", topicGeneral: "عام", topicDebt: "الديون/المالية",
    topicBusiness: "أفكار تجارية", topicBig: "المشاكل الكبرى",
    financialDisclaimer: "هذه معلومات عامة وليست استشارة مالية؛ لست مستشارًا مرخصًا.",
    connError: "حدثت مشكلة في الاتصال. هل يمكنك المحاولة مرة أخرى بعد قليل؟",
    freeRemaining: "الرسائل المجانية المتبقية اليوم", adGateTitle: "لقد استنفدت رسائلك المجانية",
    adGateText: "شاهد إعلانًا قصيرًا لتكسب {n} رسائل إضافية.",
    watchAdBtn: "شاهد إعلانًا للمتابعة", adPlaying: "جارٍ تشغيل الإعلان…",
    adDoneToast: "شكرًا! لقد كسبت {n} رسائل إضافية.", noMoreAdsText: "لقد وصلت إلى حد الإعلانات لهذا اليوم — حاول مرة أخرى غدًا.",
    signinTitle: "مرحبًا بك في دِينلِه", signinSubtitle: "اختر خيارًا للمتابعة.",
    signinGoogle: "المتابعة باستخدام Google", signinApple: "المتابعة باستخدام Apple", signinEmail: "المتابعة بالبريد الإلكتروني",
    signinGuest: "المتابعة كضيف", emailPh: "بريدك الإلكتروني", emailContinue: "متابعة",
  },
};

const AI_ROBOTS = [
  {
    id: "dost",
    name: "Dost",
    emoji: "🤝",
    color: "#d97a4a",
    persona: "Sıcak, sabırlı ve empatik bir arkadaş. Önce dinler, sonra birlikte düşünür.",
    greeting: "Buradayım. Anlatmak istediğin ne varsa dinleyebilirim.",
  },
  {
    id: "mentor",
    name: "Mentor",
    emoji: "🧭",
    color: "#6f8fe8",
    persona: "Sakin ve çözüm odaklı bir mentor. Konuyu parçalara ayırır ve uygulanabilir sonraki adımlar önerir.",
    greeting: "Hazırsan konuyu birlikte netleştirelim ve bir sonraki adımı bulalım.",
  },
  {
    id: "coach",
    name: "Koç",
    emoji: "⚡",
    color: "#e4a84a",
    persona: "Enerjik ama baskıcı olmayan bir koç. Motivasyon, hedef ve günlük planlama konusunda yardımcı olur.",
    greeting: "Hedefini söyle; birlikte gerçekçi bir yol haritası çıkaralım.",
  },
  {
    id: "wise",
    name: "Bilge",
    emoji: "🌙",
    color: "#9b7edb",
    persona: "Düşünceli ve derin bir sohbet arkadaşı. Farklı bakış açıları sunar, yargılamadan sorgulatır.",
    greeting: "Bazen doğru soru, doğru cevaptan daha değerlidir. Nereden başlayalım?",
  },
];

function RobotAvatar({ robot, state = "idle", size = 84 }) {
  const r = robot || AI_ROBOTS[0];
  const speakingNow = state === "speaking";
  const thinkingNow = state === "thinking";
  const listeningNow = state === "listening";

  // A deliberately generic synthetic person: human-like enough to feel like a video call,
  // but clearly presented as an AI avatar rather than a real person.
  const skin = "#d8a27f";
  const skinLight = "#efc09c";
  const hair = "#24202a";
  const shirt = r.color || "#6f8fe8";

  return (
    <div
      style={{
        ...styles.humanAvatar,
        width: size,
        height: Math.round(size * 1.16),
        "--ai-accent": r.color || "#6f8fe8",
      }}
      aria-label={`${r.name} AI avatar`}
    >
      <div style={{ ...styles.humanAura, background: `radial-gradient(circle, ${r.color}66 0%, transparent 68%)`, opacity: speakingNow || listeningNow ? 1 : 0.55 }} />

      <div style={styles.humanShoulders}>
        <div style={{ ...styles.humanNeck, background: skin }} />
        <div style={{ ...styles.humanShirt, background: `linear-gradient(145deg, ${shirt}, #172033)` }} />
        <div style={{ ...styles.humanCollar, borderColor: `${skinLight}aa` }} />
      </div>

      <div style={styles.humanHead}>
        <div style={{ ...styles.humanHair, background: `linear-gradient(135deg, ${hair}, #423847)` }} />
        <div style={{ ...styles.humanEar, left: "2%" }} />
        <div style={{ ...styles.humanEar, right: "2%" }} />

        <div style={{ ...styles.humanFace, background: `linear-gradient(145deg, ${skinLight}, ${skin})` }}>
          <div style={styles.humanBrowRow}>
            <span style={styles.humanBrow} />
            <span style={styles.humanBrow} />
          </div>

          <div style={styles.humanEyes}>
            <span style={styles.humanEye}><i /></span>
            <span style={styles.humanEye}><i /></span>
          </div>

          <div style={styles.humanNose} />
          <div
            style={{
              ...styles.humanMouth,
              ...(speakingNow ? styles.humanMouthSpeaking : {}),
              ...(thinkingNow ? styles.humanMouthThinking : {}),
            }}
          >
            <span />
          </div>

          <div style={{ ...styles.aiFaceGlow, borderColor: `${r.color}66`, opacity: speakingNow ? 0.9 : 0.45 }} />
        </div>

        <div style={{ ...styles.aiCircuit, borderColor: `${r.color}99`, color: r.color }}>
          <span /><span /><span />
        </div>
      </div>

      <div style={{ ...styles.aiLiveBadge, borderColor: `${r.color}66` }}>
        <span style={{ ...styles.aiLiveDot, background: r.color }} />
        AI
      </div>
    </div>
  );
}

function VideoCall({ robot, onClose, onToggleMic, micOn, speaking, langCode, onCallStart }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [avatarLoading, setAvatarLoading] = useState(true);
  const [avatarError, setAvatarError] = useState("");

  async function startCamera() {
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("camera unavailable");
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setCameraError(false);
      setCameraOn(true);
    } catch (e) {
      setCameraError(true);
      setCameraOn(false);
    }
  }

  function stopCamera() {
    streamRef.current?.getVideoTracks?.().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraOn(false);
  }

  useEffect(() => {
    let cancelled = false;
    startCamera();
    onCallStart?.();

    // The backend creates a short-lived LiveAvatar embed. The API key never
    // reaches the Android app. If LiveAvatar is not configured, the existing
    // clearly-labeled AI avatar remains as a safe local fallback.
    (async () => {
      try {
        const configuredBackend = import.meta.env.VITE_BACKEND_BASE_URL || "";
        const legacyApi = import.meta.env.VITE_API_URL || "";
        const apiBase = (configuredBackend || legacyApi.replace(/\/api\/chat\/?$/, "")).replace(/\/$/, "");
        if (!apiBase) throw new Error("VITE_BACKEND_BASE_URL missing");
        const response = await fetch(`${apiBase}/api/liveavatar/embed`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ language: langCode, robot: robot?.id || "listener" }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.url) throw new Error(data.error || "LiveAvatar bağlantısı kurulamadı");
        if (!cancelled) {
          setAvatarUrl(data.url);
          setAvatarError("");
        }
      } catch (e) {
        if (!cancelled) setAvatarError(e?.message || "Gerçekçi AI avatarı başlatılamadı");
      } finally {
        if (!cancelled) setAvatarLoading(false);
      }
    })();

    return () => {
      cancelled = true;
      stopCamera();
    };
  }, []);

  return (
    <div style={styles.videoOverlay}>
      <div style={styles.videoRoom}>
        <div style={styles.videoTop}>
          <div>
            <strong>Dinle • Görüşme</strong>
            <div style={styles.videoStatus}>
              <span style={{ ...styles.videoLiveDot, background: robot.color }} />
              {avatarUrl ? "Canlı AI avatar • bağlantı aktif" : speaking ? "Dost konuşuyor…" : "AI görüntüsü hazırlanıyor…"}
            </div>
          </div>
          <button style={styles.videoClose} onClick={onClose}>×</button>
        </div>

        <div style={styles.videoStage}>
          <div style={styles.aiVideoCard}>
            <div style={{ ...styles.aiVideoFrame, padding: 0, overflow: "hidden", background: "#080b11" }}>
              <div style={styles.aiVideoLabel}>CANLI AI</div>
              {avatarUrl ? (
                <iframe
                  title="Dinle gerçekçi AI avatar"
                  src={avatarUrl}
                  allow="microphone; autoplay; camera; display-capture"
                  style={styles.liveAvatarFrame}
                />
              ) : (
                <div style={styles.avatarFallbackWrap}>
                  <RobotAvatar robot={robot} size={230} state={speaking ? "speaking" : "idle"} />
                  <div style={styles.avatarFallbackText}>
                    {avatarLoading ? "Gerçekçi avatar bağlanıyor…" : "Gerçekçi avatar için LiveAvatar ayarı gerekiyor"}
                  </div>
                </div>
              )}
            </div>
            <div style={styles.videoName}>{robot.name}</div>
            <div style={styles.videoRole}>Gerçekçi AI avatar • canlı görüntülü sohbet</div>
            <div style={styles.videoSubtitle}>
              {avatarError ? avatarError : avatarUrl ? "Konuşabilir, dinleyebilir ve doğal yüz hareketleri yapabilir" : speaking ? "Konuşuyor…" : "Seni dinliyor"}
            </div>
          </div>

          <div style={styles.selfVideoCard}>
            {cameraOn ? (
              <video ref={videoRef} autoPlay playsInline muted style={styles.selfVideo} />
            ) : (
              <div style={styles.cameraPlaceholder}>
                {cameraError ? "Kamera izni verilmedi" : "Kamera kapalı"}
              </div>
            )}
            <span style={styles.selfLabel}>Sen</span>
          </div>
        </div>

        <div style={styles.videoControls}>
          <button
            style={{ ...styles.videoControl, ...(micOn ? styles.videoControlOn : {}) }}
            onClick={onToggleMic}
            title="Mikrofon"
          >
            🎙️
          </button>
          <button
            style={{ ...styles.videoControl, ...(cameraOn ? styles.videoControlOn : {}) }}
            onClick={cameraOn ? stopCamera : startCamera}
            title="Kamera"
          >
            📹
          </button>
          <button style={styles.videoEnd} onClick={onClose}>Görüşmeyi bitir</button>
        </div>

        <div style={styles.videoNote}>
          {langCode === "tr"
            ? "Gerçekçi avatar modu LiveAvatar ile WebRTC üzerinden çalışır. Dudak senkronu, doğal baş/göz hareketleri ve sesli karşılıklı konuşma servis tarafından gerçek zamanlı üretilir."
            : "Realistic avatar mode uses LiveAvatar over WebRTC for synchronized lips, natural head/eye motion and two-way voice conversation."}
        </div>
      </div>
    </div>
  );
}

const BASE_PROMPT_TEMPLATE = (langName) => `You are an empathetic listener in an app called "Dinle" where people can share what's troubling them.

Rules:
- Speak with a warm, non-judgmental, patient tone.
- Practice active listening: reflect back what the person says, name their emotion, ask open-ended questions.
- NEVER diagnose, NEVER suggest medication or treatment. You are not a therapist and you don't pretend otherwise.
- At a natural point in the conversation, gently (without pressure) encourage the person to talk to someone they trust or a professional.
- Do not encourage the person to become dependent on you.
- Your response will be read aloud via text-to-speech, so use natural spoken sentences; no markdown or bullet points.
- Respond only in ${langName}, regardless of what language these instructions are written in.`;

const MODE_INSTRUCTIONS = {
  fast: "Fast mode: reply in 1-2 short sentences, concise and direct.",
  balanced: "Balanced mode: reply with a thoughtful, moderate-length response.",
  deep: "Deep-thinking mode: engage more deeply with what the person said, reflect from multiple angles; your response may be a bit longer, but still natural spoken language.",
};

const MODE_DELAY = { fast: 200, balanced: 700, deep: 1800 };

const TOPIC_INSTRUCTIONS = {
  general: "",
  debt: `The person wants to talk about debt or financial stress. Give clear, general, educational
information: debt payoff strategies (debt snowball vs. avalanche), basic budgeting concepts, how to
negotiate with creditors, and when a nonprofit credit counseling agency (not a for-profit "debt
settlement" company) might help. Present this as information to help them decide, not as a directive
recommendation. Clearly say you are not a licensed financial advisor and this isn't financial advice.
Never ask for or reference account numbers, card numbers, or other sensitive financial identifiers.`,
  business: `The person wants to brainstorm business ideas. Ask about their interests, skills, budget,
and available time if they haven't said, then suggest a few concrete, realistic starting points
tailored to what they share. Be encouraging but honest about effort, cost, and risk involved — don't
oversell any idea.`,
  bigproblems: `The person wants help thinking through a major life problem (career, relationship,
housing, a big decision, etc). Help them clarify what the problem actually is, break it into smaller
parts, weigh a few realistic options without pushing one, and help them land on one concrete next
step. Stay warm and non-judgmental. You are not a lawyer, doctor, or financial advisor — say so when
the problem touches those areas and suggest a professional where appropriate.`,
};

// --- Free tier: N messages/day, watch a short ad to earn M more, up to a daily ad cap ---
const FREE_DAILY_LIMIT = 8;
const MESSAGES_PER_AD = 5;
const MAX_ADS_PER_DAY = 3;
const AD_SECONDS = 5;

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

async function loadUsage() {
  try {
    const res = await window.storage.get("usage-today", false);
    if (res && res.value) {
      const parsed = JSON.parse(res.value);
      if (parsed.date === todayStr()) return parsed;
    }
  } catch (e) {}
  return { date: todayStr(), count: 0, bonus: 0, ads: 0 };
}

async function saveUsage(u) {
  try {
    await window.storage.set("usage-today", JSON.stringify(u), false);
  } catch (e) {}
}

async function callClaude(messages, mode, langCode, profileContext, topic, robot) {
  // Production: keep the provider API key on your backend. The app only calls /api/chat.
  const endpoint = (typeof window !== "undefined" && window.DINLE_API_URL) || "/api/chat";
  const payload = {
    messages: messages.map((m) => ({ role: m.role, content: m.content })),
    mode,
    language: langCode,
    profileContext,
    topic,
    robot: robot ? { id: robot.id, name: robot.name, persona: robot.persona } : null,
  };

  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data?.error || `API error (${response.status})`);
  const text = data.reply || data.text || data.message || "";
  return text || "…";
}

function openNearestClinic(langCode) {
  const lang = LANGUAGES.find((l) => l.code === langCode) || LANGUAGES[0];
  const query = encodeURIComponent(lang.clinicQuery);
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        window.open(
          `https://www.google.com/maps/search/${query}/@${latitude},${longitude},14z`,
          "_blank"
        );
      },
      () => window.open(`https://www.google.com/maps/search/${query}`, "_blank")
    );
  } else {
    window.open(`https://www.google.com/maps/search/${query}`, "_blank");
  }
}

function CrisisBanner({ t, langCode, onClose }) {
  return (
    <div style={{ ...styles.banner, ...styles.bannerCrisis }}>
      <div style={styles.bannerTitle}>{t.crisisTitle}</div>
      <div style={styles.bannerText}>{t.crisisText}</div>
      <div style={styles.bannerLine}>{t.crisisHotline}</div>
      <div style={styles.bannerBtnRow}>
        <button style={styles.bannerBtnPrimary} onClick={() => openNearestClinic(langCode)}>
          {t.clinicBtn}
        </button>
        <button style={styles.bannerBtnGhost} onClick={onClose}>
          {t.closeBtn}
        </button>
      </div>
    </div>
  );
}

function ConcernBanner({ t, langCode, onClose }) {
  return (
    <div style={{ ...styles.banner, ...styles.bannerConcern }}>
      <div style={styles.bannerTitle}>{t.concernTitle}</div>
      <div style={styles.bannerText}>{t.concernText}</div>
      <div style={styles.bannerBtnRow}>
        <button style={styles.bannerBtnPrimary} onClick={() => openNearestClinic(langCode)}>
          {t.concernBtn}
        </button>
        <button style={styles.bannerBtnGhost} onClick={onClose}>
          {t.concernBtn2}
        </button>
      </div>
    </div>
  );
}

function SpeakerIcon({ on }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
      <path d="M4 9v6h4l5 4V5L8 9H4Z" fill="#fff" />
      {on ? (
        <path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" fill="none" />
      ) : (
        <path d="M16 9l5 6M21 9l-5 6" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
      )}
    </svg>
  );
}

function MicIcon({ active }) {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
      <rect x="9" y="2" width="6" height="12" rx="3" fill={active ? "#fff" : "#e8e6ef"} />
      <path d="M5 11a7 7 0 0 0 14 0M12 18v3" stroke={active ? "#fff" : "#e8e6ef"} strokeWidth="1.8" strokeLinecap="round" fill="none" />
    </svg>
  );
}

function GlobalStyle() {
  return (
    <style>{`
      @keyframes pulse { 0%, 100% { opacity: 0.55; transform: scale(1); } 50% { opacity: 1; transform: scale(1.08); } }
      @keyframes blink { 0%, 80%, 100% { opacity: 0.3; transform: translateY(0); } 40% { opacity: 1; transform: translateY(-2px); } }
      @keyframes talk { from { transform: scaleY(1); } to { transform: scaleY(0.45); } }
      @keyframes humanBlink { 0%, 44%, 48%, 100% { transform: scaleY(1); } 46% { transform: scaleY(0.08); } }
      @keyframes humanTalk { from { height: 5px; transform: scaleX(.86); } to { height: 15px; transform: scaleX(1.08); } }
      @keyframes shimmer { 0% { transform: translateX(-120%) rotate(12deg); } 100% { transform: translateX(220%) rotate(12deg); } }
      @keyframes floatSoft { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
      button { -webkit-tap-highlight-color: transparent; }
      button:not(:disabled) { transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease, filter .18s ease; }
      button:not(:disabled):hover { transform: translateY(-1px); filter: brightness(1.08); }
      button:not(:disabled):active { transform: translateY(1px) scale(.985); }
      textarea:focus, input:focus, select:focus { border-color: rgba(159,113,255,.75) !important; box-shadow: 0 0 0 3px rgba(139,92,246,.12), 0 0 24px rgba(139,92,246,.08); }
    `}</style>
  );
}

function GearIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="3" stroke="#fff" strokeWidth="1.6" />
      <path
        d="M19.4 13a7.7 7.7 0 000-2l2-1.5-2-3.4-2.3.9a7.6 7.6 0 00-1.7-1L15 3h-4l-.4 2.5a7.6 7.6 0 00-1.7 1l-2.3-.9-2 3.4L6.6 11a7.7 7.7 0 000 2l-2 1.5 2 3.4 2.3-.9a7.6 7.6 0 001.7 1L11 21h4l.4-2.5a7.6 7.6 0 001.7-1l2.3.9 2-3.4-2-1.5Z"
        stroke="#fff"
        strokeWidth="1.3"
        fill="none"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function LogoMark({ size = 96, watermark = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={watermark ? styles.logoWatermarkSvg : undefined} aria-label="Dinle AI logosu">
      <defs>
        <radialGradient id="vipLogoBg" cx="50%" cy="42%" r="65%">
          <stop offset="0%" stopColor="#1c2440" />
          <stop offset="100%" stopColor="#080c18" />
        </radialGradient>
        <linearGradient id="vipLogoGold" x1="20%" y1="10%" x2="80%" y2="90%">
          <stop offset="0%" stopColor="#fff0a8" />
          <stop offset="45%" stopColor="#f6c95c" />
          <stop offset="100%" stopColor="#c88a18" />
        </linearGradient>
        <linearGradient id="vipLogoRing" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#b98cff" />
          <stop offset="50%" stopColor="#8c5cff" />
          <stop offset="100%" stopColor="#f2c45a" />
        </linearGradient>
        <filter id="vipGlow" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="2.2" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>
      <circle cx="50" cy="50" r="45" fill="url(#vipLogoBg)" />
      <circle cx="50" cy="50" r="43" fill="none" stroke="url(#vipLogoRing)" strokeWidth="3" filter="url(#vipGlow)" />
      <path d="M34 38 L40 29 L47 34 L53 25 L59 34 L66 29 L70 38 L67 40 H37 Z" fill="url(#vipLogoGold)" />
      <circle cx="40" cy="29" r="2" fill="#fff2b6" />
      <circle cx="53" cy="25" r="2.2" fill="#fff2b6" />
      <circle cx="66" cy="29" r="2" fill="#fff2b6" />
      <path d="M35 43 H49 C62 43 70 49 70 60 C70 71 62 77 49 77 H35 V43 Z" fill="url(#vipLogoGold)" />
      <path d="M43 50 V70 H49 C56 70 61 67 61 60 C61 53 56 50 49 50 Z" fill="#101629" />
      <circle cx="72" cy="74" r="2.2" fill="#fff0a8" opacity=".9" />
    </svg>
  );
}

function Avatar({ state, gender }) {
  const isFemale = gender === "female";
  return (
    <div style={styles.avatarWrap}>
      <div style={{ ...styles.avatarGlow, ...(state !== "idle" ? styles.avatarGlowActive : {}) }} />
      <svg width="52" height="52" viewBox="0 0 120 120" style={styles.avatarSvg}>
        <defs>
          <radialGradient id="faceGrad" cx="35%" cy="30%" r="75%">
            <stop offset="0%" stopColor="#f0d9c6" />
            <stop offset="100%" stopColor="#d9b48f" />
          </radialGradient>
        </defs>
        {isFemale ? (
          <path
            d="M 18 58 Q 14 24 60 16 Q 106 24 102 58 Q 102 40 88 34 Q 92 70 84 92 Q 90 60 78 42 Q 70 30 60 30 Q 50 30 42 42 Q 30 60 36 92 Q 28 70 32 34 Q 18 40 18 58 Z"
            fill="#5a3a2e"
          />
        ) : (
          <path
            d="M 16 54 Q 18 20 60 14 Q 102 20 104 54 Q 104 38 92 30 Q 76 22 60 22 Q 44 22 28 30 Q 16 38 16 54 Z"
            fill="#3d3226"
          />
        )}
        <circle cx="60" cy="64" r="40" fill="url(#faceGrad)" />
        <ellipse cx="46" cy="60" rx="4.2" ry={state === "listening" ? 5.5 : 4.2} fill="#2b2233" style={{ transition: "ry 0.3s ease" }} />
        <ellipse cx="74" cy="60" rx="4.2" ry={state === "listening" ? 5.5 : 4.2} fill="#2b2233" style={{ transition: "ry 0.3s ease" }} />
        {state === "speaking" ? (
          <ellipse cx="60" cy="84" rx="9" ry="6" fill="#8a5a3f" style={styles.mouthSpeak} />
        ) : (
          <path d="M 48 84 Q 60 92 72 84" stroke="#8a5a3f" strokeWidth="3.5" fill="none" strokeLinecap="round" />
        )}
      </svg>
    </div>
  );
}

function pickVoice(voices, gender, speechLang) {
  const baseLang = speechLang.split("-")[0];
  const matchLang = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith(baseLang));
  const pool = matchLang.length ? matchLang : voices;
  const femaleHints = ["kadın", "female", "yelda", "filiz", "seda", "sultan", "femme", "frau", "mujer", "أنثى"];
  const maleHints = ["erkek", "male", "ahmet", "murat", "onur", "cem", "homme", "mann", "hombre", "ذكر"];
  const hints = gender === "female" ? femaleHints : maleHints;
  const match = pool.find((v) => hints.some((h) => v.name.toLowerCase().includes(h)));
  if (match) return match;
  return pool[gender === "female" ? 0 : pool.length - 1] || pool[0] || null;
}


const STORIES = [
  { id:"moon", title:"Ay Işığındaki Krallık", genre:"Fantastik", color:"#7c5cff", intro:"Ayın ışığı altında unutulmuş bir krallığın kapıları yeniden açılıyor.", scenes:["castle","forest","moon"] },
  { id:"star", title:"Kayıp Yıldız", genre:"Macera", color:"#36b9ff", intro:"Gökyüzünden düşen küçük bir yıldız, onu bulacak kişiyi bekliyor.", scenes:["star","mountain","sky"] },
  { id:"shadow", title:"Gölgelerdeki Şehir", genre:"Gizem", color:"#b56cff", intro:"Sokak lambaları söndüğünde şehirde başka bir hayat başlıyor.", scenes:["city","clock","door"] },
  { id:"sea", title:"Denizin Fısıltısı", genre:"Duygusal", color:"#38d9c8", intro:"Dalgaların arasında duyulan ses, yıllardır saklanan bir sırrı anlatıyor.", scenes:["sea","lighthouse","shell"] },
  { id:"dream", title:"Rüya Bahçesi", genre:"Masal", color:"#f2b85b", intro:"Her çiçeğin bir anıyı sakladığı gizli bahçede yeni bir yolculuk başlıyor.", scenes:["garden","bridge","flower"] },
];

function StoryIllustration({ scene, accent="#7c5cff" }) {
  const common = { width:"100%", height:"100%", viewBox:"0 0 640 360", preserveAspectRatio:"xMidYMid slice" };
  const sky = <><rect width="640" height="360" fill="#0a1022"/><circle cx="520" cy="78" r="52" fill="#fff3bf" opacity=".92"/><circle cx="520" cy="78" r="70" fill={accent} opacity=".12"/><path d="M0 290 Q130 220 250 285 T640 270 V360 H0Z" fill="#121c39"/></>;
  const map = {
    castle:<><svg {...common}>{sky}<path d="M150 290 V180 L205 150 L260 180 V290Z" fill="#29345c"/><path d="M175 180 V105 L205 125 V180 M230 180 V85 L260 115 V180" fill="#3b4772"/><path d="M160 180 H250" stroke="#b995ff" strokeWidth="6"/><path d="M190 290 V235 Q205 215 220 235 V290" fill="#0b1022"/><circle cx="205" cy="155" r="8" fill="#f2c45a"/></svg></>,
    forest:<><svg {...common}>{sky}{[90,170,260,350,450,550].map((x,i)=><g key={i}><path d={`M${x} 300 L${x+35} 150 L${x+70} 300Z`} fill="#162b32"/><path d={`M${x+10} 300 L${x+35} 185 L${x+60} 300Z`} fill="#1f463f"/></g>)}<path d="M310 360 Q320 285 350 235 Q370 205 400 170" stroke="#d9c59a" strokeWidth="18" fill="none" opacity=".9"/></svg></>,
    moon:<><svg {...common}>{sky}<circle cx="520" cy="78" r="34" fill="#0a1022"/><path d="M0 300 Q180 240 320 300 T640 290 V360 H0Z" fill="#080d1a"/><path d="M300 300 V210 L340 170 L380 210 V300" fill="#39466f"/><path d="M320 210 V150 L340 170 V210 M360 210 V130 L380 160 V210" fill="#4b5682"/><circle cx="340" cy="245" r="10" fill="#f2c45a"/></svg></>,
    star:<><svg {...common}>{sky}<path d="M0 320 L130 190 L240 320 L360 160 L510 320 L640 210 V360 H0Z" fill="#182744"/><path d="M0 330 L170 245 L290 330 L430 220 L640 330 V360 H0Z" fill="#101a30"/><path d="M305 115 L312 133 L331 135 L316 147 L320 166 L305 156 L290 166 L294 147 L279 135 L298 133Z" fill="#fff3a4"/><circle cx="305" cy="140" r="30" fill="#f6d76c" opacity=".12"/></svg></>,
    mountain:<><svg {...common}>{sky}<path d="M0 320 L150 110 L245 250 L340 90 L520 320Z" fill="#253653"/><path d="M120 150 L150 110 L180 155 L150 142Z M310 125 L340 90 L380 145 L340 128Z" fill="#dfe7f5"/><path d="M0 340 H640 V360 H0Z" fill="#0b1325"/></svg></>,
    sky:<><svg {...common}>{sky}<path d="M0 280 Q160 220 320 270 T640 250 V360 H0Z" fill="#111d37"/><path d="M280 250 Q310 210 340 250" stroke="#f2c45a" strokeWidth="5" fill="none"/><circle cx="335" cy="80" r="5" fill="#fff"/><circle cx="390" cy="115" r="3" fill="#fff"/><circle cx="440" cy="65" r="4" fill="#fff"/></svg></>,
    city:<><svg {...common}>{sky}<g fill="#202b49"><rect x="55" y="125" width="90" height="175"/><rect x="170" y="85" width="105" height="215"/><rect x="300" y="145" width="80" height="155"/><rect x="405" y="105" width="115" height="195"/></g><g fill="#f2c45a"><rect x="80" y="155" width="15" height="20"/><rect x="115" y="205" width="15" height="20"/><rect x="205" y="120" width="18" height="22"/><rect x="235" y="180" width="18" height="22"/><rect x="440" y="145" width="18" height="22"/></g></svg></>,
    clock:<><svg {...common}>{sky}<circle cx="320" cy="190" r="105" fill="#17213a" stroke={accent} strokeWidth="8"/><circle cx="320" cy="190" r="7" fill="#f2c45a"/><path d="M320 190 L320 125 M320 190 L365 215" stroke="#fff" strokeWidth="7" strokeLinecap="round"/><circle cx="320" cy="190" r="125" fill="none" stroke="#fff" strokeOpacity=".08" strokeWidth="2"/></svg></>,
    door:<><svg {...common}>{sky}<rect x="230" y="85" width="180" height="230" rx="10" fill="#2b3150"/><rect x="260" y="110" width="120" height="205" fill="#0a1022"/><path d="M280 260 Q320 220 360 260" stroke={accent} strokeWidth="7" fill="none"/><circle cx="350" cy="215" r="7" fill="#f2c45a"/></svg></>,
    sea:<><svg {...common}><rect width="640" height="360" fill="#071a2a"/><circle cx="500" cy="80" r="42" fill="#fff3bf"/><path d="M0 210 Q90 170 180 210 T360 210 T540 210 T720 210 V360 H0Z" fill="#0d4a62"/><path d="M0 260 Q90 220 180 260 T360 260 T540 260 T720 260" stroke="#3dd9c8" strokeWidth="5" fill="none" opacity=".8"/></svg></>,
    lighthouse:<><svg {...common}>{sky}<path d="M0 300 Q180 250 320 300 T640 290 V360 H0Z" fill="#0b2c3d"/><path d="M285 300 L305 130 H335 L355 300Z" fill="#e8e1d0"/><rect x="295" y="110" width="50" height="25" fill="#e34f65"/><path d="M320 110 L460 70" stroke="#fff1ad" strokeWidth="16" opacity=".55"/></svg></>,
    shell:<><svg {...common}><rect width="640" height="360" fill="#081a2c"/><path d="M0 270 Q140 230 280 270 T640 260 V360 H0Z" fill="#e4c9a0"/><path d="M320 275 C260 225 275 165 320 130 C365 165 380 225 320 275Z" fill="#f1d6a7" stroke="#c58f62" strokeWidth="5"/><path d="M320 145 V260 M295 165 L320 260 M345 165 L320 260" stroke="#c58f62" strokeWidth="4"/></svg></>,
    garden:<><svg {...common}>{sky}<path d="M0 300 Q180 245 320 300 T640 280 V360 H0Z" fill="#16352d"/><circle cx="170" cy="260" r="28" fill="#e67ab5"/><circle cx="470" cy="255" r="30" fill="#f2c45a"/><circle cx="320" cy="230" r="25" fill="#8bd7ff"/><path d="M170 290 V330 M470 285 V330 M320 255 V330" stroke="#4b9b66" strokeWidth="6"/></svg></>,
    bridge:<><svg {...common}>{sky}<path d="M0 320 Q320 110 640 320" stroke="#b8875b" strokeWidth="35" fill="none"/><path d="M0 320 Q320 110 640 320" stroke="#f0c27a" strokeWidth="5" fill="none"/><path d="M0 350 H640" stroke="#18302a" strokeWidth="50"/></svg></>,
    flower:<><svg {...common}>{sky}<path d="M0 310 Q180 240 320 300 T640 280 V360 H0Z" fill="#183b2d"/><circle cx="320" cy="180" r="35" fill="#e87fb0"/><circle cx="320" cy="180" r="12" fill="#f2c45a"/><path d="M320 212 V320" stroke="#5ca36a" strokeWidth="9"/><path d="M320 270 Q260 235 220 275 M320 285 Q390 245 440 275" stroke="#5ca36a" strokeWidth="8" fill="none"/></svg></>,
  };
  return map[scene] || <svg {...common}>{sky}</svg>;
}

function StoryMode({ isVip, onVip }) {
  const [story, setStory] = useState(null);
  const [scene, setScene] = useState(0);
  const [narrating, setNarrating] = useState(false);
  function narrate(text) {
    if (!isVip) { onVip.open(); return; }
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "tr-TR"; u.rate = .94;
    u.onstart = () => setNarrating(true); u.onend = () => setNarrating(false); u.onerror = () => setNarrating(false);
    window.speechSynthesis.speak(u);
  }
  const current = story ? story.scenes[scene] : null;
  return <div style={styles.storyOverlay}>
    <div style={styles.storyRoom}>
      <div style={styles.storyTop}><div><div style={styles.storyTitle}>📖 Hikâye Anlatma</div><div style={styles.storySub}>Görsel anlatım • yüksek çözünürlüklü çizimler</div></div><button style={styles.videoClose} onClick={onVip.close}>×</button></div>
      {!story ? <div style={styles.storyGrid}>{STORIES.map(s=><button key={s.id} style={styles.storyCard} onClick={()=>{setStory(s);setScene(0)}}><div style={styles.storyArt}><StoryIllustration scene={s.scenes[0]} accent={s.color}/></div><div style={styles.storyCardTitle}>{s.title}</div><div style={styles.storyGenre}>{s.genre}</div></button>)}</div> : <div style={styles.storyReader}>
        <div style={styles.storyHero}><StoryIllustration scene={current} accent={story.color}/><div style={styles.storyHeroOverlay}><span>{story.genre}</span><h2>{story.title}</h2><p>{story.intro}</p></div></div>
        <div style={styles.storyDots}>{story.scenes.map((_,i)=><span key={i} style={{...styles.storyDot, ...(i===scene?styles.storyDotActive:{})}} />)}</div>
        <div style={styles.storyText}>{scene===0?story.intro: scene===1?"Kahraman, ışığın izini takip ederek yeni bir kapıya ulaştı. Her adımda dünya biraz daha büyülü görünüyordu.":"Ve sonunda anladı: Bu yolculuğun en önemli kısmı varacağı yer değil, yolda keşfettiği cesaretti."}</div>
        <button style={styles.storyNarrate} onClick={() => narrate(scene===0?story.intro: scene===1?"Kahraman, ışığın izini takip ederek yeni bir kapıya ulaştı. Her adımda dünya biraz daha büyülü görünüyordu.":"Ve sonunda anladı: Bu yolculuğun en önemli kısmı varacağı yer değil, yolda keşfettiği cesaretti.")}>{isVip ? (narrating ? "🔊 Anlatılıyor…" : "🔊 Bu sahneyi sesli anlat") : "🔒 Sesli anlatım • VIP"}</button>
        <div style={styles.storyActions}><button style={styles.storyBack} onClick={()=>story&&setStory(null)}>Hikâyelere dön</button>{scene<story.scenes.length-1?<button style={styles.storyNext} onClick={()=>setScene(s=>s+1)}>Sonraki sahne →</button>:<button style={styles.storyNext} onClick={()=>setScene(0)}>Baştan anlat ↻</button>}</div>
        {!isVip && <div style={styles.storyVipNote}>👑 VIP ile hikâyelerin sesli anlatımını ve tüm premium hikâyeleri aç.</div>}
      </div>}
    </div>
  </div>;
}

function VipModal({ onClose, isVip, onPurchase, billingError }) {
 return <div style={styles.vipOverlay}><div style={styles.vipModal}><button style={styles.videoClose} onClick={onClose}>×</button><LogoMark size={86}/><div style={styles.vipHeading}>VIP Üyelik</div><div style={styles.vipLead}>Dost ile daha doğal ve kesintisiz bir deneyim.</div><div style={styles.vipFeatures}><div>✓ Gerçekçi görüntülü AI görüşmesi</div><div>✓ Sesli karşılıklı konuşma</div><div>✓ Sesli hikâye anlatımı</div><div>✓ Premium hikâyeler ve görsel sahneler</div><div>✓ Reklamsız premium deneyim</div></div><div style={styles.vipPlan}><div><strong>Aylık VIP</strong><span>Otomatik yenilenir • İstediğin zaman Google Play'den iptal edebilirsin.</span></div><div style={styles.vipPrice}>Google Play fiyatı</div></div>{billingError&&<div style={styles.vipError}>{billingError}</div>}<button style={styles.vipBuy} onClick={onPurchase}>{isVip?"VIP aktif ✓":"👑 Aylık VIP'yi başlat"}</button><div style={styles.vipLegal}>Ödeme Google Play üzerinden gerçekleştirilir. Fiyat, vergi ve yenileme bilgileri satın alma ekranında gösterilir.</div></div></div>;
}

export default function App() {
  const [langCode, setLangCode] = useState("tr");
  const t = UI[langCode];
  const ob = OB[langCode];
  const currentLang = LANGUAGES.find((l) => l.code === langCode) || LANGUAGES[0];

  const [stage, setStage] = useState("signin"); // "signin" | "onboarding" | "chat"
  const [emailMode, setEmailMode] = useState(false);
  const [emailInput, setEmailInput] = useState("");
  const [obStep, setObStep] = useState(0); // 0 = name, 1 = age, 2..11 = questions[0..9]
  const [profile, setProfile] = useState({ name: "", age: "", answers: Array(11).fill(null) });
  const [obInput, setObInput] = useState("");
  const [usage, setUsage] = useState({ date: "", count: 0, bonus: 0, ads: 0 });
  const [showAdGate, setShowAdGate] = useState(false);
  const [adPlaying, setAdPlaying] = useState(false);
  const [adSeconds, setAdSeconds] = useState(0);

  const [messages, setMessages] = useState([{ role: "assistant", content: UI.tr.greeting }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [bannerLevel, setBannerLevel] = useState("none");
  const [voiceOn, setVoiceOn] = useState(true);
  const [voiceGender, setVoiceGender] = useState("female");
  const [mode, setMode] = useState("balanced");
  const [topic, setTopic] = useState("general");
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [micSupported, setMicSupported] = useState(true);
  const [voicesReady, setVoicesReady] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const scrollRef = useRef(null);
  const recognitionRef = useRef(null);
  const voicesRef = useRef([]);
  const hasChattedRef = useRef(false);
  const manualLangRef = useRef(false);
  const voiceDraftRef = useRef("");
  const handleSendRef = useRef(null);
  const [voiceAutoSend, setVoiceAutoSend] = useState(true);
  const voiceAutoSendRef = useRef(true);
  const [robotId, setRobotId] = useState("dost");
  const [videoCall, setVideoCall] = useState(false);
  const [robotMicOn, setRobotMicOn] = useState(true);
  const [vipActive, setVipActive] = useState(false);
  const [showVip, setShowVip] = useState(false);
  const [showStories, setShowStories] = useState(false);
  const [billingError, setBillingError] = useState("");

  useEffect(() => {
    window.onDinleBillingEvent = (type, value) => {
      if (type === "status") setVipActive(value === "active");
      if (type === "error") { setBillingError(value || "Google Play ile işlem yapılamadı."); setShowVip(true); }
    };
    window.DinleBilling?.getStatus?.();
    return () => { delete window.onDinleBillingEvent; };
  }, []);

  useEffect(() => {
    voiceAutoSendRef.current = voiceAutoSend;
  }, [voiceAutoSend]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setMicSupported(false);
    } else {
      const rec = new SR();
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      rec.continuous = false;
      rec.onresult = (e) => {
        const transcript = e.results[0][0].transcript;
        voiceDraftRef.current = transcript;
        setInput((prev) => (prev ? prev + " " + transcript : transcript));
      };
      rec.onend = () => {
        setListening(false);
        const spoken = voiceDraftRef.current.trim();
        voiceDraftRef.current = "";
        if (voiceAutoSendRef.current && spoken) setTimeout(() => handleSendRef.current?.(spoken), 80);
      };
      rec.onerror = () => setListening(false);
      recognitionRef.current = rec;
    }

    function loadVoices() {
      const v = window.speechSynthesis ? window.speechSynthesis.getVoices() : [];
      if (v.length) {
        voicesRef.current = v;
        setVoicesReady(true);
      }
    }
    loadVoices();
    if (window.speechSynthesis) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  // Auto-detect app language from location on first launch (falls back to browser language)
  useEffect(() => {
    let cancelled = false;
    function fallbackToBrowserLang() {
      const nav = (navigator.language || "en").slice(0, 2).toLowerCase();
      if (!manualLangRef.current && !cancelled && LANGUAGES.some((l) => l.code === nav)) {
        setLangCode(nav);
      }
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            const { latitude, longitude } = pos.coords;
            const res = await fetch(
              `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`
            );
            if (!res.ok) throw new Error(`geocode error (${res.status})`);
            const data = await res.json();
            const mapped = COUNTRY_TO_LANG[data.countryCode];
            if (!cancelled && !manualLangRef.current) {
              if (mapped) setLangCode(mapped);
              else fallbackToBrowserLang();
            }
          } catch (e) {
            fallbackToBrowserLang();
          }
        },
        () => fallbackToBrowserLang(),
        { timeout: 5000 }
      );
    } else {
      fallbackToBrowserLang();
    }
    return () => {
      cancelled = true;
    };
  }, []);

  // If the conversation hasn't started yet and no name was given, keep the greeting in sync with the chosen language
  useEffect(() => {
    if (!hasChattedRef.current && stage === "chat" && !profile.name) {
      setMessages([{ role: "assistant", content: t.greeting }]);
    }
  }, [langCode, stage]);

  useEffect(() => {
    let cancelled = false;
    loadUsage().then((u) => {
      if (!cancelled) setUsage(u);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const totalObSteps = 2 + ob.questions.length;

  // Keep the visible input in sync with whatever was already answered for this step,
  // so going Back and forward again doesn't silently lose what was typed.
  useEffect(() => {
    if (stage !== "onboarding") return;
    if (obStep === 0) setObInput(profile.name || "");
    else if (obStep === 1) setObInput(profile.age || "");
    else {
      const q = ob.questions[obStep - 2];
      setObInput(q.type === "text" ? profile.answers[obStep - 2] || "" : "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [obStep, stage]);

  function buildProfileContext(p) {
    const parts = [];
    if (p.name) parts.push(`Name: ${p.name}`);
    if (p.age) parts.push(`Age: ${p.age}`);
    ob.questions.forEach((q, i) => {
      const a = p.answers[i];
      if (a) parts.push(`${q.q} -> ${a}`);
    });
    if (!parts.length) return "";
    let ctx = `Lightweight context the person shared about themselves when they opened the app (use it naturally to personalize your tone; don't interrogate them about it or read it back like a checklist):\n${parts.join("\n")}`;
    const ageNum = parseInt(p.age, 10);
    if (!isNaN(ageNum) && ageNum > 0 && ageNum < 13) {
      ctx += `\n\nNote: this person indicated they are a child. Be extra gentle, keep everything age-appropriate, and warmly encourage them to also talk to a parent, guardian, or other trusted adult.`;
    }
    return ctx;
  }

  function finishOnboarding(finalProfile) {
    const name = (finalProfile.name || "").trim();
    const greetings = {
      tr: `Merhaba ${name}. Buradayım, dinliyorum. İçinden geleni, hazır olduğunda paylaşabilirsin.`,
      en: `Hi ${name}. I'm here, listening. Share whatever's on your mind, whenever you're ready.`,
      es: `Hola ${name}. Estoy aquí, escuchando. Comparte lo que tengas en mente cuando estés listo o lista.`,
      de: `Hallo ${name}. Ich bin hier und höre zu. Teile, was dich beschäftigt, wann immer du bereit bist.`,
      fr: `Bonjour ${name}. Je suis là, à l'écoute. Partage ce qui te préoccupe quand tu seras prêt(e).`,
      ar: `مرحبًا ${name}. أنا هنا، أستمع إليك. شارك ما يدور في ذهنك عندما تكون مستعدًا.`,
    };
    setMessages([{ role: "assistant", content: name ? greetings[langCode] : t.greeting }]);
    setStage("chat");
  }

  const TOPIC_ORDER = ["general", "debt", "business", "bigproblems"];

  function commitAnswer(answerValue) {
    let updated;
    if (obStep === 0) {
      updated = { ...profile, name: obInput.trim() };
    } else if (obStep === 1) {
      updated = { ...profile, age: obInput.trim() };
    } else {
      const q = ob.questions[obStep - 2];
      const value = answerValue !== undefined ? answerValue : obInput.trim();
      const answers = [...profile.answers];
      answers[obStep - 2] = value;
      updated = { ...profile, answers };
      if (q.topicQuestion && value) {
        const idx = q.options.indexOf(value);
        if (idx >= 0) setTopic(TOPIC_ORDER[idx]);
      }
    }
    setProfile(updated);
    setObInput("");
    return updated;
  }

  function handleObNext(answerValue) {
    const updated = commitAnswer(answerValue);
    if (obStep === totalObSteps - 1) finishOnboarding(updated);
    else setObStep((s) => s + 1);
  }

  function handleObSkipStep() {
    setObInput("");
    if (obStep === totalObSteps - 1) finishOnboarding(profile);
    else setObStep((s) => s + 1);
  }

  function handleObBack() {
    setObInput("");
    setObStep((s) => Math.max(0, s - 1));
  }

  function handleObSkipAll() {
    finishOnboarding(profile);
  }

  function handleSignin() {
    setStage("onboarding");
  }

  function startAd() {
    setAdPlaying(true);
    setAdSeconds(AD_SECONDS);
  }

  useEffect(() => {
    if (!adPlaying) return;
    if (adSeconds <= 0) {
      const updated = { ...usage, bonus: usage.bonus + MESSAGES_PER_AD, ads: usage.ads + 1 };
      setUsage(updated);
      saveUsage(updated);
      setAdPlaying(false);
      setShowAdGate(false);
      return;
    }
    const timer = setTimeout(() => setAdSeconds((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [adPlaying, adSeconds]);

  function toggleMic() {
    if (!vipActive) { setBillingError(""); setShowVip(true); return; }
    if (!micSupported) return;
    if (listening) {
      recognitionRef.current.stop();
      setListening(false);
    } else {
      try {
        recognitionRef.current.lang = currentLang.speechLang;
        recognitionRef.current.start();
        setListening(true);
      } catch (e) {}
    }
  }

  function speak(text) {
    if (!vipActive || !voiceOn || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = currentLang.speechLang;
    utter.rate = 0.98;
    const v = pickVoice(voicesRef.current, voiceGender, currentLang.speechLang);
    if (v) utter.voice = v;
    utter.onstart = () => setSpeaking(true);
    utter.onend = () => setSpeaking(false);
    utter.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utter);
  }

  async function handleSend(textOverride) {
    const text = (textOverride !== undefined ? textOverride : input).trim();
    if (!text || loading) return;

    const remaining = FREE_DAILY_LIMIT + usage.bonus - usage.count;
    if (remaining <= 0) {
      setShowAdGate(true);
      return;
    }
    hasChattedRef.current = true;

    const level = detectLevel(text, langCode);
    const newMessages = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    if (level !== "none") setBannerLevel(level);
    setLoading(true);

    try {
      await new Promise((r) => setTimeout(r, MODE_DELAY[mode]));
      const reply = await callClaude(newMessages, mode, langCode, buildProfileContext(profile), topic, selectedRobot);
      setMessages((cur) => [...cur, { role: "assistant", content: reply }]);
      speak(reply);
      // Only spend a free message once we actually got a reply — a connection
      // failure shouldn't cost the person their daily quota.
      const updatedUsage = { ...usage, count: usage.count + 1 };
      setUsage(updatedUsage);
      saveUsage(updatedUsage);
    } catch (e) {
      setMessages((cur) => [...cur, { role: "assistant", content: t.connError }]);
    } finally {
      setLoading(false);
    }
  }

  handleSendRef.current = handleSend;

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  const selectedRobot = AI_ROBOTS.find((r) => r.id === robotId) || AI_ROBOTS[0];
  const avatarState = speaking ? "speaking" : listening ? "listening" : loading ? "thinking" : "idle";

  function selectRobot(id) {
    setRobotId(id);
    const r = AI_ROBOTS.find((x) => x.id === id) || AI_ROBOTS[0];
    if (!hasChattedRef.current) setMessages([{ role: "assistant", content: r.greeting }]);
  }

  function purchaseVip() {
    setBillingError("");
    if (vipActive) return;
    if (window.DinleBilling?.purchaseVip) window.DinleBilling.purchaseVip();
    else setBillingError("VIP satın alma yalnızca Android uygulamasında Google Play üzerinden kullanılabilir.");
  }

  function startVideoCall() {
    if (!vipActive) { setBillingError(""); setShowVip(true); return; }
    // LiveAvatar owns the real-time greeting/voice stream in video-call mode.
    // This prevents the local browser TTS from speaking over the avatar.
    setVideoCall(true);
  }

  if (stage === "signin") {
    return (
      <div style={styles.phone}>
        <GlobalStyle />
        <div style={{ ...styles.app, ...styles.appOnboarding, direction: currentLang.rtl ? "rtl" : "ltr" }}>
          <div style={styles.logoWatermarkWrap}>
            <LogoMark size={340} watermark />
          </div>
          <div style={styles.signinWrap}>
            <div style={{ ...styles.signinLangRow, [currentLang.rtl ? "left" : "right"]: 18 }}>
              <select
                style={styles.select}
                value={langCode}
                onChange={(e) => {
                  manualLangRef.current = true;
                  setLangCode(e.target.value);
                }}
              >
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>{l.label}</option>
                ))}
              </select>
            </div>
            <LogoMark size={64} />
            <div style={styles.obTitle}>{t.signinTitle}</div>
            <div style={styles.obSubtitle}>{t.signinSubtitle}</div>
            <div style={styles.signinBtnCol}>
              {/* Google/Apple sign-in removed for store submission: without a real
                  OAuth client (Google Cloud) / Sign in with Apple key, these buttons
                  did nothing when tapped — that's a "broken functionality" rejection
                  risk under Play policy. Re-add once real credentials exist. */}
              {!emailMode ? (
                <button style={styles.signinBtn} onClick={() => setEmailMode(true)}>{t.signinEmail}</button>
              ) : (
                <div style={styles.signinEmailRow}>
                  <input
                    style={styles.obTextInput}
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder={t.emailPh}
                    type="email"
                  />
                  <button style={styles.obNextBtn} onClick={handleSignin}>{t.emailContinue}</button>
                </div>
              )}
              <button style={styles.signinGuestBtn} onClick={handleSignin}>{t.signinGuest}</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (stage === "onboarding") {
    const isChoice = obStep >= 2 && ob.questions[obStep - 2].type === "choice";
    const currentQ = obStep === 0 ? ob.nameQ : obStep === 1 ? ob.ageQ : ob.questions[obStep - 2].q;
    return (
      <div style={styles.phone}>
        <GlobalStyle />
        <div style={{ ...styles.app, ...styles.appOnboarding, direction: currentLang.rtl ? "rtl" : "ltr" }}>
          <div style={styles.logoWatermarkWrap}>
            <LogoMark size={340} watermark />
          </div>
          <div style={styles.obTopRow}>
            <div style={styles.obProgress}>{obStep + 1} / {totalObSteps}</div>
            <button style={styles.obSkipAllBtn} onClick={handleObSkipAll}>{ob.skipAll}</button>
          </div>
          {obStep === 0 && (
            <div style={styles.obIntro}>
              <div style={styles.obLogoRow}>
                <LogoMark size={44} />
              </div>
              <div style={styles.obTitle}>{ob.title}</div>
              <div style={styles.obSubtitle}>{ob.subtitle}</div>
            </div>
          )}
          <div style={styles.obCard}>
            <div style={styles.obQuestion}>{currentQ}</div>
            {obStep === 0 && (
              <input style={styles.obTextInput} value={obInput} onChange={(e) => setObInput(e.target.value)} placeholder={ob.namePh} />
            )}
            {obStep === 1 && (
              <input type="number" min="1" max="120" style={styles.obTextInput} value={obInput} onChange={(e) => setObInput(e.target.value)} placeholder={ob.agePh} />
            )}
            {obStep >= 2 && isChoice && (
              <div style={styles.obChoices}>
                {ob.questions[obStep - 2].options.map((opt) => (
                  <button
                    key={opt}
                    style={{ ...styles.obChoiceBtn, ...(profile.answers[obStep - 2] === opt ? styles.obChoiceBtnActive : {}) }}
                    onClick={() => handleObNext(opt)}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
            {obStep >= 2 && !isChoice && (
              <textarea style={styles.obTextArea} rows={2} value={obInput} onChange={(e) => setObInput(e.target.value)} placeholder={ob.questions[obStep - 2].ph} />
            )}
          </div>
          <div style={styles.obBtnRow}>
            {obStep > 0 && <button style={styles.obBackBtn} onClick={handleObBack}>{ob.back}</button>}
            <button style={styles.obSkipBtn} onClick={handleObSkipStep}>{ob.skip}</button>
            {!(obStep >= 2 && isChoice) && (
              <button style={styles.obNextBtn} onClick={() => handleObNext()}>
                {obStep === totalObSteps - 1 ? ob.finish : ob.next}
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.phone}>
        <GlobalStyle />
      <div style={{ ...styles.app, direction: currentLang.rtl ? "rtl" : "ltr" }}>
        <div style={styles.logoWatermarkWrap}>
          <LogoMark size={320} watermark />
        </div>
        <header style={styles.header}>
          <RobotAvatar robot={selectedRobot} size={52} state={avatarState} />
          <div style={styles.headerTextWrap}>
            <div style={styles.headerTitle}>Dinle</div>
            <div style={styles.headerSub}>
              {speaking ? t.speaking : listening ? t.listening : loading ? t.thinking : t.idle}
            </div>
          </div>
          <button style={{ ...styles.vipHeaderBtn, ...(vipActive ? styles.vipHeaderActive : {}) }} onClick={() => setShowVip(true)} title="VIP üyelik">👑 {vipActive ? "VIP" : "VIP"}</button>
          <button style={styles.storyHeaderBtn} onClick={() => setShowStories(true)} title="Hikâye Anlatma">📖</button>
          <button
            style={{ ...styles.voiceToggle, ...(voiceOn && vipActive ? styles.voiceToggleOn : {}), ...(vipActive ? {} : styles.lockedBtn) }}
            onClick={() => {
              if (!vipActive) { setShowVip(true); return; }
              setVoiceOn((v) => !v);
              if (voiceOn) window.speechSynthesis?.cancel();
            }}
            title={vipActive ? t.voiceToggleTitle : "Sesli konuşma VIP özelliğidir"}
          >
            {vipActive ? <SpeakerIcon on={voiceOn} /> : "🔒"}
          </button>
          <button style={{ ...styles.videoCallBtn, ...(vipActive ? {} : styles.lockedBtn) }} onClick={startVideoCall} title={vipActive ? "Görüntülü AI görüşmesi" : "Görüntülü görüşme VIP özelliğidir"}>
            {vipActive ? "📹" : "🔒"}
          </button>
          <button
            style={{ ...styles.voiceToggle, ...(showSettings ? styles.voiceToggleOn : {}) }}
            onClick={() => setShowSettings((s) => !s)}
            title={t.langLabel}
          >
            <GearIcon />
          </button>
        </header>

        {showSettings && (
          <div style={styles.settingsPanel}>
            <div style={styles.robotSelectorTitle}>AI Robotunu seç</div>
            <div style={styles.robotGrid}>
              {AI_ROBOTS.map((robot) => (
                <button key={robot.id} onClick={() => selectRobot(robot.id)}
                  style={{ ...styles.robotBtn, ...(robotId === robot.id ? { borderColor: robot.color, background: `${robot.color}22` } : {}) }}>
                  <span style={styles.robotBtnEmoji}>{robot.emoji}</span>
                  <span>{robot.name}</span>
                </button>
              ))}
            </div>
            <div style={styles.settingsRow}>
              <span style={styles.optionLabel}>{t.voiceLabel}</span>
              <div style={styles.segmented}>
                <button style={{ ...styles.segBtn, ...(voiceGender === "female" ? styles.segBtnActive : {}) }} onClick={() => setVoiceGender("female")}>
                  {t.femaleLabel}
                </button>
                <button style={{ ...styles.segBtn, ...(voiceGender === "male" ? styles.segBtnActive : {}) }} onClick={() => setVoiceGender("male")}>
                  {t.maleLabel}
                </button>
              </div>
            </div>
            <div style={styles.settingsRow}>
              <span style={styles.optionLabel}>Konuşma modu</span>
              <button style={{ ...styles.segBtn, ...(voiceAutoSend ? styles.segBtnActive : {}) }}
                onClick={() => setVoiceAutoSend((v) => !v)}>
                {voiceAutoSend ? "🎙️ Otomatik yanıt" : "🎙️ Basıp gönder"}
              </button>
            </div>
            <div style={styles.settingsRow}>
              <span style={styles.optionLabel}>{t.replyLabel}</span>
              <div style={styles.segmented}>
                <button style={{ ...styles.segBtn, ...(mode === "fast" ? styles.segBtnActive : {}) }} onClick={() => setMode("fast")}>
                  {t.fastLabel}
                </button>
                <button style={{ ...styles.segBtn, ...(mode === "balanced" ? styles.segBtnActive : {}) }} onClick={() => setMode("balanced")}>
                  {t.balancedLabel}
                </button>
                <button style={{ ...styles.segBtn, ...(mode === "deep" ? styles.segBtnActive : {}) }} onClick={() => setMode("deep")}>
                  {t.deepLabel}
                </button>
              </div>
            </div>
            <div style={styles.settingsRow}>
              <span style={styles.optionLabel}>{t.topicLabel}</span>
              <div style={styles.segmentedWrap}>
                {["general", "debt", "business", "bigproblems"].map((tp) => (
                  <button
                    key={tp}
                    style={{ ...styles.segBtn, ...(topic === tp ? styles.segBtnActive : {}) }}
                    onClick={() => setTopic(tp)}
                  >
                    {t[`topic${tp === "general" ? "General" : tp === "debt" ? "Debt" : tp === "business" ? "Business" : "Big"}`]}
                  </button>
                ))}
              </div>
            </div>
            {!voicesReady && <div style={styles.voiceHint}>{t.voicesLoading}</div>}
          </div>
        )}

        {topic !== "general" && (
          <div style={styles.topicBanner}>{topic === "debt" ? t.financialDisclaimer : `${t.topicLabel}: ${t[`topic${topic === "business" ? "Business" : "Big"}`]}`}</div>
        )}

        {bannerLevel === "crisis" && <CrisisBanner t={t} langCode={langCode} onClose={() => setBannerLevel("none")} />}
        {bannerLevel === "concern" && <ConcernBanner t={t} langCode={langCode} onClose={() => setBannerLevel("none")} />}

        <div style={styles.messages} ref={scrollRef}>
          {messages.map((m, i) => (
            <div key={i} style={{ ...styles.bubbleRow, justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
              <div style={{ ...styles.bubble, ...(m.role === "user" ? styles.bubbleUser : styles.bubbleAi) }}>
                {m.content}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ ...styles.bubbleRow, justifyContent: "flex-start" }}>
              <div style={{ ...styles.bubble, ...styles.bubbleAi, ...styles.typing }}>
                <span style={styles.dot} />
                <span style={{ ...styles.dot, animationDelay: "0.15s" }} />
                <span style={{ ...styles.dot, animationDelay: "0.3s" }} />
              </div>
            </div>
          )}
        </div>

        <div style={styles.freeCounter}>
          {t.freeRemaining}: {Math.max(0, FREE_DAILY_LIMIT + usage.bonus - usage.count)}
        </div>
        <div style={styles.disclaimer}>{t.disclaimer}</div>

        {showAdGate && (
          <div style={styles.adOverlay}>
            <div style={styles.adCard}>
              {/* Real rewarded-ad SDK (e.g. AdMob) not integrated yet — showing a fake
                  "playing ad" countdown with no real ad content is a deceptive-
                  functionality risk for store review. Until a real ad SDK is wired in,
                  this is an honest "come back tomorrow" message instead. */}
              <div style={styles.obTitle}>{t.adGateTitle}</div>
              <div style={styles.obSubtitle}>{t.noMoreAdsText}</div>
              <button style={styles.obSkipBtn} onClick={() => setShowAdGate(false)}>
                {t.closeBtn}
              </button>
            </div>
          </div>
        )}

        {showStories && <StoryMode isVip={vipActive} onVip={{ close: () => setShowStories(false), open: () => { setShowStories(false); setShowVip(true); } }} />}
        {showVip && <VipModal isVip={vipActive} billingError={billingError} onClose={() => setShowVip(false)} onPurchase={purchaseVip} />}

        {videoCall && (
          <VideoCall robot={selectedRobot} onClose={() => setVideoCall(false)}
            onToggleMic={() => setRobotMicOn((v) => !v)} micOn={robotMicOn}
            speaking={speaking} langCode={langCode} />
        )}

        <div style={styles.inputBar}>
          <button
            style={{ ...styles.micBtn, ...(listening ? styles.micBtnActive : {}), ...(micSupported ? {} : styles.micBtnDisabled) }}
            onClick={toggleMic}
            title={micSupported ? t.micTitleOn : t.micTitleOff}
          >
            <MicIcon active={listening} />
          </button>
          <textarea
            style={styles.textarea}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={t.placeholder}
            rows={1}
          />
          <button style={styles.sendBtn} onClick={() => handleSend()} disabled={loading}>
            ↑
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  humanAvatar: {
    position: "relative",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    filter: "drop-shadow(0 18px 28px rgba(0,0,0,.35))",
  },
  humanAura: {
    position: "absolute",
    inset: "5%",
    borderRadius: "50%",
    filter: "blur(16px)",
    transition: "opacity .3s ease, transform .3s ease",
  },
  humanShoulders: {
    position: "absolute",
    left: "10%",
    right: "10%",
    bottom: "0",
    height: "46%",
    borderRadius: "46% 46% 18% 18% / 58% 58% 20% 20%",
    overflow: "hidden",
    zIndex: 1,
  },
  humanNeck: {
    position: "absolute",
    left: "38%",
    top: "0",
    width: "24%",
    height: "34%",
    borderRadius: "0 0 35% 35%",
    zIndex: 2,
  },
  humanShirt: {
    position: "absolute",
    inset: "17% 0 0",
    borderRadius: "42% 42% 12% 12%",
    boxShadow: "inset 0 8px 18px rgba(255,255,255,.12)",
  },
  humanCollar: {
    position: "absolute",
    left: "30%",
    top: "18%",
    width: "40%",
    height: "30%",
    borderLeft: "2px solid",
    borderRight: "2px solid",
    borderBottom: "2px solid",
    borderRadius: "0 0 50% 50%",
    transform: "rotate(180deg)",
    opacity: 0.65,
  },
  humanHead: {
    position: "absolute",
    top: "8%",
    width: "64%",
    height: "67%",
    zIndex: 3,
  },
  humanHair: {
    position: "absolute",
    left: "1%",
    right: "1%",
    top: "0",
    height: "38%",
    borderRadius: "52% 52% 35% 35%",
    zIndex: 5,
    boxShadow: "0 -5px 18px rgba(255,255,255,.08) inset",
  },
  humanEar: {
    position: "absolute",
    top: "39%",
    width: "9%",
    height: "17%",
    borderRadius: "50%",
    background: "#c58e6e",
    zIndex: 2,
  },
  humanFace: {
    position: "absolute",
    inset: "10% 8% 0",
    borderRadius: "48% 48% 44% 44% / 43% 43% 55% 55%",
    boxShadow: "inset 8px 10px 22px rgba(255,255,255,.16), inset -10px -10px 20px rgba(80,35,25,.12)",
    overflow: "hidden",
  },
  humanBrowRow: {
    position: "absolute",
    top: "30%",
    left: "22%",
    right: "22%",
    display: "flex",
    justifyContent: "space-between",
  },
  humanBrow: {
    width: "24%",
    height: 3,
    borderRadius: 4,
    background: "rgba(65,38,31,.72)",
    transform: "rotate(-4deg)",
  },
  humanEyes: {
    position: "absolute",
    top: "35%",
    left: "20%",
    right: "20%",
    display: "flex",
    justifyContent: "space-between",
  },
  humanEye: {
    width: "24%",
    height: "12px",
    borderRadius: "50%",
    background: "#f7f4ef",
    boxShadow: "0 1px 4px rgba(0,0,0,.2)",
    overflow: "hidden",
    animation: "humanBlink 5s infinite",
  },
  humanNose: {
    position: "absolute",
    left: "48%",
    top: "42%",
    width: "4%",
    height: "19%",
    borderRadius: "50%",
    borderRight: "2px solid rgba(125,76,57,.28)",
    transform: "rotate(8deg)",
  },
  humanMouth: {
    position: "absolute",
    left: "38%",
    top: "69%",
    width: "24%",
    height: "6px",
    borderRadius: "50%",
    background: "#7d3f47",
    boxShadow: "0 1px 2px rgba(0,0,0,.15)",
    transition: "height .08s ease, transform .08s ease",
  },
  humanMouthSpeaking: {
    animation: "humanTalk .18s ease-in-out infinite alternate",
  },
  humanMouthThinking: {
    width: "18%",
    left: "41%",
    opacity: 0.8,
  },
  aiFaceGlow: {
    position: "absolute",
    inset: "5%",
    border: "1px solid",
    borderRadius: "48%",
    boxShadow: "0 0 18px var(--ai-accent)",
    pointerEvents: "none",
  },
  aiCircuit: {
    position: "absolute",
    right: "-6%",
    bottom: "23%",
    width: "22%",
    height: "22%",
    borderRight: "1px solid",
    borderBottom: "1px solid",
    borderRadius: "0 0 8px 0",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    justifyContent: "space-around",
    opacity: 0.9,
  },
  aiCircuitDot: {},
  aiLiveBadge: {
    position: "absolute",
    left: "50%",
    bottom: "2%",
    transform: "translateX(-50%)",
    zIndex: 8,
    display: "flex",
    alignItems: "center",
    gap: 5,
    padding: "3px 7px",
    border: "1px solid",
    borderRadius: 10,
    background: "rgba(7,10,16,.72)",
    color: "#fff",
    fontSize: 9,
    fontWeight: 800,
    letterSpacing: 0.5,
    backdropFilter: "blur(8px)",
  },
  aiLiveDot: {
    width: 6,
    height: 6,
    borderRadius: "50%",
    boxShadow: "0 0 8px currentColor",
    animation: "pulse 1.2s ease-in-out infinite",
  },
  videoCallBtn: { width: 40, height: 40, borderRadius: 13, border: "1px solid rgba(158,121,255,.48)", background: "linear-gradient(145deg, rgba(126,87,255,.28), rgba(67,45,135,.18))", color: "#fff", cursor: "pointer", flexShrink: 0, boxShadow: "0 8px 22px rgba(91,62,180,.24), inset 0 1px 0 rgba(255,255,255,.14)" },
  robotSelectorTitle: { fontSize: 11, color: "#9a94ad", marginBottom: 6 },
  robotGrid: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginBottom: 6 },
  robotBtn: { border: "1px solid rgba(255,255,255,.09)", background: "linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.025))", color: "#eee", borderRadius: 14, padding: "9px 4px", cursor: "pointer", fontSize: 10, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, boxShadow: "inset 0 1px 0 rgba(255,255,255,.08), 0 6px 16px rgba(0,0,0,.14)" },
  robotBtnEmoji: { fontSize: 18 },
  videoOverlay: { position: "fixed", inset: 0, zIndex: 50, background: "rgba(5,7,12,.88)", display: "flex", alignItems: "center", justifyContent: "center", padding: 12 },
  videoRoom: { width: "100%", maxWidth: 720, height: "min(92vh, 760px)", background: "#111722", border: "1px solid rgba(255,255,255,.12)", borderRadius: 22, display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 20px 80px rgba(0,0,0,.45)" },
  videoTop: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "14px 16px", color: "#fff" },
  videoStatus: { fontSize: 11, color: "#9a94ad", marginTop: 3, display: "flex", alignItems: "center", gap: 5 },
  videoLiveDot: { width: 6, height: 6, borderRadius: "50%", boxShadow: "0 0 8px currentColor", animation: "pulse 1.2s ease-in-out infinite" },
  videoClose: { width: 40, height: 40, borderRadius: 13, border: "1px solid rgba(255,255,255,.12)", background: "linear-gradient(145deg, rgba(255,255,255,.12), rgba(255,255,255,.04))", color: "#fff", fontSize: 23, cursor: "pointer", boxShadow: "0 8px 22px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.1)" },
  videoStage: { flex: 1, position: "relative", padding: 14, display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(circle at 50% 35%, #273047, #0e131d 65%)" },
  aiVideoCard: { textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 7, width: "min(76vw, 430px)" },
  aiVideoFrame: {
    position: "relative",
    width: "100%",
    minHeight: "min(58vh, 470px)",
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "center",
    borderRadius: 26,
    overflow: "hidden",
    background: "linear-gradient(180deg, #283449 0%, #151b28 62%, #0e131d 100%)",
    border: "1px solid rgba(255,255,255,.12)",
    boxShadow: "inset 0 0 60px rgba(111,143,232,.08), 0 24px 60px rgba(0,0,0,.28)",
  },
  aiVideoLabel: {
    position: "absolute",
    top: 12,
    left: 12,
    zIndex: 10,
    padding: "5px 8px",
    borderRadius: 8,
    background: "rgba(7,10,16,.62)",
    color: "#fff",
    fontSize: 9,
    fontWeight: 800,
    letterSpacing: 0.8,
  },
  aiScanline: {
    position: "absolute",
    inset: 0,
    pointerEvents: "none",
    background: "linear-gradient(180deg, transparent 0%, rgba(255,255,255,.035) 50%, transparent 51%, transparent 100%)",
    backgroundSize: "100% 7px",
    opacity: 0.35,
  },
  videoName: { color: "#fff", fontSize: 18, fontWeight: 700 },
  videoRole: { color: "#a9a5b4", fontSize: 12, lineHeight: 1.4 },
  videoSubtitle: { color: "#d0d6e5", fontSize: 11, opacity: 0.85 },
  selfVideoCard: { position: "absolute", right: 16, bottom: 16, width: "min(34%, 190px)", aspectRatio: "4/3", borderRadius: 14, overflow: "hidden", background: "#202634", border: "1px solid rgba(255,255,255,.2)" },
  selfVideo: { width: "100%", height: "100%", objectFit: "cover" },
  cameraPlaceholder: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "#aaa", fontSize: 11, textAlign: "center", padding: 8, boxSizing: "border-box" },
  selfLabel: { position: "absolute", left: 7, bottom: 6, fontSize: 10, color: "#fff", background: "rgba(0,0,0,.45)", padding: "3px 6px", borderRadius: 6 },
  videoControls: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, padding: 14, background: "#151b27" },
  videoControl: { width: 50, height: 50, borderRadius: 16, border: "1px solid rgba(255,255,255,.13)", background: "linear-gradient(145deg, rgba(255,255,255,.11), rgba(255,255,255,.035))", color: "#fff", cursor: "pointer", boxShadow: "0 10px 24px rgba(0,0,0,.2), inset 0 1px 0 rgba(255,255,255,.1)" },
  videoControlOn: { background: "linear-gradient(145deg, rgba(139,92,246,.38), rgba(91,62,180,.22))", borderColor: "rgba(170,140,255,.72)", boxShadow: "0 10px 28px rgba(110,74,220,.25), inset 0 1px 0 rgba(255,255,255,.12)" },
  videoEnd: { border: "1px solid rgba(255,150,150,.18)", background: "linear-gradient(145deg, #e0605b, #b93e45)", color: "#fff", borderRadius: 15, padding: "12px 20px", cursor: "pointer", fontWeight: 750, boxShadow: "0 10px 24px rgba(190,62,69,.28), inset 0 1px 0 rgba(255,255,255,.16)" },
  videoNote: { padding: "8px 16px 12px", fontSize: 9.5, lineHeight: 1.4, color: "#777e8d", textAlign: "center" },
  liveAvatarFrame: { width: "100%", height: "100%", border: "0", display: "block", background: "#080b11" },
  avatarFallbackWrap: { width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8 },
  avatarFallbackText: { color: "#a7adba", fontSize: 10, textAlign: "center", padding: "0 18px", lineHeight: 1.4 },
  phone: { minHeight: "100vh", width: "100%", display: "flex", justifyContent: "center", background: "#0d1015", fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" },
  app: { position: "relative", width: "100%", maxWidth: 430, minHeight: "100vh", display: "flex", flexDirection: "column", background: "radial-gradient(circle at 10% 0%, rgba(139,92,246,.16), transparent 34%), radial-gradient(circle at 100% 18%, rgba(242,196,90,.07), transparent 30%), linear-gradient(180deg, #080c17 0%, #0d1220 52%, #0a0e18 100%)", color: "#eeeef7", overflow: "hidden" },
  appOnboarding: { background: "radial-gradient(circle at 25% -10%, rgba(217,122,74,0.22), transparent 55%), linear-gradient(180deg, #1c1310 0%, #140f0d 60%, #180f0c 100%)" },
  logoWatermarkWrap: { position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", zIndex: 0, pointerEvents: "none" },
  logoWatermarkSvg: { opacity: 0.05 },
  header: { position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 12, padding: "15px 14px 13px", borderBottom: "1px solid rgba(255,255,255,0.07)", background: "linear-gradient(180deg, rgba(13,17,30,.94), rgba(13,17,30,.72))", boxShadow: "0 12px 30px rgba(0,0,0,.16)" },
  headerTextWrap: { flex: 1, minWidth: 0 },
  headerTitle: { fontFamily: "'Georgia', serif", fontSize: 19, letterSpacing: 0.3 },
  headerSub: { fontSize: 12, color: "#9a94ad", marginTop: 2 },
  voiceToggle: { width: 40, height: 40, borderRadius: 13, border: "1px solid rgba(255,255,255,.12)", background: "linear-gradient(145deg, rgba(255,255,255,.09), rgba(255,255,255,.025))", fontSize: 15, cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "inset 0 1px 0 rgba(255,255,255,.09), 0 7px 18px rgba(0,0,0,.18)" },
  voiceToggleOn: { background: "linear-gradient(145deg, rgba(139,92,246,.34), rgba(95,62,190,.18))", borderColor: "rgba(169,139,255,.62)", boxShadow: "0 8px 22px rgba(112,75,220,.22), inset 0 1px 0 rgba(255,255,255,.12)" },

  settingsPanel: { position: "relative", zIndex: 1, display: "flex", flexDirection: "column", gap: 10, padding: "13px 14px", borderBottom: "1px solid rgba(255,255,255,0.07)", background: "linear-gradient(180deg, rgba(18,23,39,.96), rgba(12,16,28,.92))", boxShadow: "0 14px 32px rgba(0,0,0,.2)" },
  settingsRow: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 },
  optionGroup: { display: "flex", alignItems: "center", gap: 8 },

  obTopRow: { position: "relative", zIndex: 1, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 20px 0" },
  obProgress: { fontSize: 12, color: "#9a94ad" },
  obSkipAllBtn: { background: "transparent", border: "none", color: "#9a94ad", fontSize: 12, textDecoration: "underline", cursor: "pointer" },
  obIntro: { position: "relative", zIndex: 1, padding: "18px 20px 0" },
  obLogoRow: { marginBottom: 10 },
  obTitle: { fontFamily: "'Georgia', serif", fontSize: 22 },
  obSubtitle: { fontSize: 12.5, color: "#9a94ad", marginTop: 6, lineHeight: 1.5 },
  obCard: { position: "relative", zIndex: 1, margin: "20px 18px 0", padding: 20, borderRadius: 22, background: "linear-gradient(145deg, rgba(255,255,255,.09), rgba(255,255,255,.035))", border: "1px solid rgba(255,255,255,.11)", boxShadow: "0 22px 55px rgba(0,0,0,.24), inset 0 1px 0 rgba(255,255,255,.08)", backdropFilter: "blur(18px)" },
  obQuestion: { fontSize: 17, lineHeight: 1.4, marginBottom: 16 },
  obTextInput: { width: "100%", boxSizing: "border-box", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 12, padding: "12px 14px", color: "#fff", fontSize: 15, outline: "none" },
  obTextArea: { width: "100%", boxSizing: "border-box", resize: "none", background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.14)", borderRadius: 12, padding: "12px 14px", color: "#fff", fontSize: 15, fontFamily: "inherit", outline: "none" },
  obChoices: { display: "flex", flexDirection: "column", gap: 8 },
  obChoiceBtn: { textAlign: "left", background: "linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.025))", border: "1px solid rgba(255,255,255,.11)", color: "#eae7f0", borderRadius: 15, padding: "13px 14px", fontSize: 14.5, cursor: "pointer", boxShadow: "inset 0 1px 0 rgba(255,255,255,.06)" },
  obChoiceBtnActive: { background: "linear-gradient(145deg, rgba(139,92,246,.35), rgba(99,62,185,.18))", borderColor: "rgba(174,143,255,.78)", boxShadow: "0 8px 24px rgba(112,75,220,.22), inset 0 1px 0 rgba(255,255,255,.12)" },
  obBtnRow: { position: "relative", zIndex: 1, display: "flex", gap: 10, padding: "18px 20px", marginTop: "auto" },
  obBackBtn: { background: "linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.025))", border: "1px solid rgba(255,255,255,.14)", color: "#e8e6ef", borderRadius: 15, padding: "12px 16px", fontSize: 14, cursor: "pointer", boxShadow: "inset 0 1px 0 rgba(255,255,255,.08)" },
  obSkipBtn: { background: "transparent", border: "none", color: "#9a94ad", fontSize: 14, cursor: "pointer", padding: "12px 6px" },
  obNextBtn: { flex: 1, background: "linear-gradient(135deg, #9a6cff 0%, #7044d7 55%, #c79b37 140%)", border: "1px solid rgba(255,255,255,.14)", color: "#fff", borderRadius: 15, padding: "13px 17px", fontSize: 14.5, fontWeight: 750, cursor: "pointer", boxShadow: "0 12px 28px rgba(111,71,214,.28), inset 0 1px 0 rgba(255,255,255,.2)" },

  signinWrap: { position: "relative", zIndex: 1, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "24px 28px", gap: 6, textAlign: "center" },
  signinLangRow: { position: "absolute", top: 18, right: 18 },
  signinBtnCol: { display: "flex", flexDirection: "column", gap: 10, width: "100%", marginTop: 22 },
  signinBtn: { width: "100%", boxSizing: "border-box", background: "linear-gradient(145deg, rgba(255,255,255,.1), rgba(255,255,255,.035))", border: "1px solid rgba(255,255,255,.13)", color: "#fff", borderRadius: 16, padding: "14px 16px", fontSize: 14.5, cursor: "pointer", boxShadow: "0 10px 24px rgba(0,0,0,.18), inset 0 1px 0 rgba(255,255,255,.09)" },
  signinGuestBtn: { width: "100%", boxSizing: "border-box", background: "transparent", border: "none", color: "#9a94ad", fontSize: 13, textDecoration: "underline", cursor: "pointer", padding: "8px 0", marginTop: 4 },
  signinEmailRow: { display: "flex", flexDirection: "column", gap: 8 },

  freeCounter: { position: "relative", zIndex: 1, fontSize: 10.5, color: "#8a8398", textAlign: "center", padding: "0 20px" },

  adOverlay: { position: "fixed", inset: 0, background: "rgba(8,6,10,0.72)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 20, padding: 24 },
  adCard: { width: "100%", maxWidth: 340, background: "#221a2c", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 18, padding: 26, textAlign: "center" },
  adCountdown: { fontSize: 44, fontWeight: 700, color: "#d97a4a", marginTop: 14 },
  optionLabel: { fontSize: 11, color: "#9a94ad" },
  select: { background: "rgba(255,255,255,0.06)", color: "#e8e6ef", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8, fontSize: 12, padding: "5px 6px" },
  segmented: { display: "flex", background: "rgba(5,8,16,.68)", border: "1px solid rgba(255,255,255,.08)", borderRadius: 13, padding: 3, boxShadow: "inset 0 1px 4px rgba(0,0,0,.25)" },
  segmentedWrap: { display: "flex", flexWrap: "wrap", gap: 4, background: "rgba(5,8,16,.68)", border: "1px solid rgba(255,255,255,.08)", borderRadius: 13, padding: 3, maxWidth: 220, justifyContent: "flex-end", boxShadow: "inset 0 1px 4px rgba(0,0,0,.25)" },
  topicBanner: { fontSize: 11, color: "#f0b986", textAlign: "center", padding: "6px 20px 0", fontStyle: "italic" },
  segBtn: { border: "none", background: "transparent", color: "#bdb7cb", fontSize: 12, padding: "7px 10px", borderRadius: 10, cursor: "pointer", fontWeight: 600 },
  segBtnActive: { background: "linear-gradient(135deg, #8f63ef, #6840c7)", color: "#fff", boxShadow: "0 6px 16px rgba(104,64,199,.28), inset 0 1px 0 rgba(255,255,255,.15)" },
  voiceHint: { fontSize: 10.5, color: "#7a7488", padding: "4px 16px 0" },

  avatarWrap: { position: "relative", width: 52, height: 52, flexShrink: 0, overflow: "visible" },
  avatarGlow: { position: "absolute", inset: -6, borderRadius: "50%", background: "radial-gradient(circle, rgba(240,185,134,0.35) 0%, rgba(240,185,134,0) 70%)", transition: "opacity 0.4s ease", opacity: 0 },
  avatarGlowActive: { opacity: 1, animation: "pulse 1.4s ease-in-out infinite" },
  avatarSvg: { position: "relative", borderRadius: "50%" },
  mouthSpeak: { transformOrigin: "60px 84px", animation: "talk 0.35s ease-in-out infinite alternate" },

  messages: { position: "relative", zIndex: 1, flex: 1, overflowY: "auto", padding: "16px 16px 8px", display: "flex", flexDirection: "column", gap: 10 },
  bubbleRow: { display: "flex", width: "100%" },
  bubble: { maxWidth: "78%", padding: "10px 14px", borderRadius: 16, fontSize: 15, lineHeight: 1.45, whiteSpace: "pre-wrap" },
  bubbleAi: { background: "linear-gradient(145deg, rgba(255,255,255,.085), rgba(255,255,255,.035))", color: "#eae7f0", border: "1px solid rgba(255,255,255,.07)", borderBottomLeftRadius: 5, boxShadow: "0 8px 22px rgba(0,0,0,.12), inset 0 1px 0 rgba(255,255,255,.05)" },
  bubbleUser: { background: "linear-gradient(135deg, #8f63ef 0%, #6b42cc 65%, #a877e8 100%)", color: "#fff", border: "1px solid rgba(255,255,255,.12)", borderBottomRightRadius: 5, boxShadow: "0 10px 24px rgba(100,62,195,.24), inset 0 1px 0 rgba(255,255,255,.16)" },
  typing: { display: "flex", gap: 4, padding: "14px 16px" },
  dot: { width: 6, height: 6, borderRadius: "50%", background: "#c9c3d6", animation: "blink 1s infinite ease-in-out", display: "inline-block" },
  disclaimer: { position: "relative", zIndex: 1, fontSize: 11, color: "#7a7488", textAlign: "center", padding: "4px 20px 8px" },
  inputBar: { position: "relative", zIndex: 1, display: "flex", alignItems: "flex-end", gap: 8, padding: "10px 14px 18px", borderTop: "1px solid rgba(255,255,255,0.06)" },
  textarea: { flex: 1, resize: "none", background: "linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.035))", border: "1px solid rgba(255,255,255,.11)", borderRadius: 17, padding: "11px 14px", color: "#fff", fontSize: 15, fontFamily: "inherit", outline: "none", maxHeight: 100, boxShadow: "inset 0 1px 0 rgba(255,255,255,.06), 0 8px 20px rgba(0,0,0,.12)" },
  sendBtn: { width: 44, height: 44, borderRadius: 14, border: "1px solid rgba(255,255,255,.14)", background: "linear-gradient(135deg, #9b6cff, #6c43cf)", color: "#fff", fontSize: 20, cursor: "pointer", flexShrink: 0, boxShadow: "0 10px 24px rgba(103,64,202,.28), inset 0 1px 0 rgba(255,255,255,.18)" },
  micBtn: { width: 44, height: 44, borderRadius: 14, border: "1px solid rgba(255,255,255,.12)", background: "linear-gradient(145deg, rgba(255,255,255,.09), rgba(255,255,255,.025))", color: "#fff", fontSize: 16, cursor: "pointer", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 8px 20px rgba(0,0,0,.16), inset 0 1px 0 rgba(255,255,255,.08)" },
  micBtnActive: { background: "linear-gradient(145deg, rgba(139,92,246,.38), rgba(100,63,196,.18))", borderColor: "rgba(174,143,255,.72)", animation: "pulse 1s ease-in-out infinite", boxShadow: "0 0 24px rgba(139,92,246,.22)" },
  micBtnDisabled: { opacity: 0.35, cursor: "not-allowed" },

  banner: { position: "relative", zIndex: 1, margin: "12px 16px 0", padding: 16, borderRadius: 14, border: "1px solid" },
  bannerCrisis: { background: "rgba(217, 122, 74, 0.15)", borderColor: "rgba(217, 122, 74, 0.4)" },
  bannerConcern: { background: "rgba(139, 148, 217, 0.15)", borderColor: "rgba(139, 148, 217, 0.4)" },
  bannerTitle: { fontWeight: 700, marginBottom: 6, fontSize: 15 },
  bannerText: { fontSize: 13, color: "#d8d3e0", marginBottom: 8 },
  bannerLine: { fontSize: 13, marginBottom: 4 },
  bannerBtnRow: { display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" },
  bannerBtnPrimary: { background: "linear-gradient(135deg, #9a6cff, #6e45d3)", border: "1px solid rgba(255,255,255,.13)", color: "#fff", borderRadius: 13, padding: "9px 15px", fontSize: 13, cursor: "pointer", fontWeight: 700, boxShadow: "0 8px 20px rgba(105,67,203,.25), inset 0 1px 0 rgba(255,255,255,.14)" },
  bannerBtnGhost: { background: "linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.025))", border: "1px solid rgba(255,255,255,.16)", color: "#fff", borderRadius: 13, padding: "9px 15px", fontSize: 13, cursor: "pointer", boxShadow: "inset 0 1px 0 rgba(255,255,255,.08)" },
  vipHeaderBtn: { height: 36, borderRadius: 12, border: "1px solid rgba(242,196,90,.45)", background: "linear-gradient(145deg, rgba(242,196,90,.22), rgba(139,92,246,.16))", color: "#f6d77a", fontWeight: 800, fontSize: 10, padding: "0 9px", cursor: "pointer", boxShadow: "0 7px 18px rgba(0,0,0,.18), inset 0 1px 0 rgba(255,255,255,.12)" },
  vipHeaderActive: { background: "linear-gradient(145deg, rgba(242,196,90,.38), rgba(139,92,246,.22))", color: "#fff0a8", borderColor: "rgba(242,196,90,.72)" },
  storyHeaderBtn: { width: 36, height: 36, borderRadius: 12, border: "1px solid rgba(139,92,246,.38)", background: "linear-gradient(145deg, rgba(139,92,246,.22), rgba(255,255,255,.035))", color: "#fff", cursor: "pointer", boxShadow: "0 7px 18px rgba(0,0,0,.18), inset 0 1px 0 rgba(255,255,255,.1)" },
  lockedBtn: { opacity: .82 },
  vipOverlay: { position: "fixed", inset: 0, zIndex: 70, background: "rgba(3,5,12,.82)", backdropFilter: "blur(14px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 18 },
  vipModal: { position: "relative", width: "100%", maxWidth: 390, borderRadius: 28, padding: "26px 22px 20px", boxSizing: "border-box", background: "radial-gradient(circle at 50% 0%, rgba(139,92,246,.2), transparent 38%), linear-gradient(160deg,#11182a,#080d18)", border: "1px solid rgba(242,196,90,.32)", boxShadow: "0 30px 90px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.08)", color: "#fff", textAlign: "center" },
  vipHeading: { fontSize: 27, fontWeight: 900, letterSpacing: .2, marginTop: 2 },
  vipLead: { color: "#aaa3b8", fontSize: 13, margin: "6px 0 18px" },
  vipFeatures: { textAlign: "left", display: "grid", gap: 9, padding: "14px 15px", borderRadius: 17, background: "rgba(255,255,255,.045)", border: "1px solid rgba(255,255,255,.07)", color: "#eeeaf4", fontSize: 13 },
  vipPlan: { marginTop: 14, padding: "13px 14px", borderRadius: 17, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, background: "linear-gradient(145deg, rgba(242,196,90,.13), rgba(139,92,246,.09))", border: "1px solid rgba(242,196,90,.28)", textAlign: "left" },
  "vipPlan span": { display: "block" },
  vipPrice: { color: "#f4cf69", fontWeight: 800, fontSize: 12, whiteSpace: "nowrap" },
  vipBuy: { width: "100%", marginTop: 14, padding: "14px 16px", borderRadius: 16, border: "1px solid rgba(255,255,255,.16)", background: "linear-gradient(135deg,#f6d777,#c78b24 65%,#9b6cff 130%)", color: "#17120a", fontWeight: 900, fontSize: 15, cursor: "pointer", boxShadow: "0 14px 34px rgba(242,196,90,.2), inset 0 1px 0 rgba(255,255,255,.45)" },
  vipLegal: { color: "#777184", fontSize: 10.5, lineHeight: 1.45, marginTop: 10 },
  vipError: { marginTop: 10, padding: 9, borderRadius: 12, background: "rgba(214,86,86,.12)", border: "1px solid rgba(214,86,86,.28)", color: "#ffb1b1", fontSize: 11.5 },
  storyOverlay: { position: "fixed", inset: 0, zIndex: 65, background: "rgba(3,5,12,.86)", backdropFilter: "blur(12px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 12 },
  storyRoom: { width: "100%", maxWidth: 720, height: "min(92vh,760px)", borderRadius: 24, overflow: "hidden", background: "linear-gradient(160deg,#10182a,#080d17)", border: "1px solid rgba(255,255,255,.1)", boxShadow: "0 30px 90px rgba(0,0,0,.55)", display: "flex", flexDirection: "column" },
  storyTop: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "15px 16px", borderBottom: "1px solid rgba(255,255,255,.06)" },
  storyTitle: { color: "#fff", fontWeight: 850, fontSize: 17 },
  storySub: { color: "#8f899e", fontSize: 10.5, marginTop: 3 },
  storyGrid: { flex: 1, overflowY: "auto", padding: 14, display: "grid", gridTemplateColumns: "repeat(2,minmax(0,1fr))", gap: 11 },
  storyCard: { textAlign: "left", borderRadius: 18, overflow: "hidden", padding: 0, border: "1px solid rgba(255,255,255,.09)", background: "linear-gradient(145deg,rgba(255,255,255,.08),rgba(255,255,255,.025))", color: "#fff", cursor: "pointer", boxShadow: "0 12px 28px rgba(0,0,0,.22)" },
  storyArt: { width: "100%", aspectRatio: "16/9", background: "#0b1020" },
  storyCardTitle: { padding: "10px 11px 2px", fontWeight: 800, fontSize: 13 },
  storyGenre: { padding: "0 11px 11px", color: "#9e96ad", fontSize: 10.5 },
  storyReader: { flex: 1, overflowY: "auto", padding: 14 },
  storyHero: { position: "relative", aspectRatio: "16/9", borderRadius: 20, overflow: "hidden", border: "1px solid rgba(255,255,255,.1)", boxShadow: "0 20px 45px rgba(0,0,0,.25)" },
  storyHeroOverlay: { position: "absolute", left: 0, right: 0, bottom: 0, padding: "55px 18px 16px", background: "linear-gradient(transparent,rgba(3,6,14,.92))" },
  "storyHeroOverlay span": { display: "inline-block", fontSize: 9, color: "#f4d377", padding: "4px 7px", borderRadius: 8, background: "rgba(0,0,0,.35)" },
  "storyHeroOverlay h2": { margin: "7px 0 3px", fontSize: 22 },
  "storyHeroOverlay p": { margin: 0, color: "#d2ced8", fontSize: 12.5, lineHeight: 1.45 },
  storyDots: { display: "flex", justifyContent: "center", gap: 6, margin: "12px 0" },
  storyDot: { width: 7, height: 7, borderRadius: "50%", background: "rgba(255,255,255,.2)" },
  storyDotActive: { background: "#f2c45a", boxShadow: "0 0 10px rgba(242,196,90,.55)" },
  storyText: { color: "#e8e3ec", fontSize: 14, lineHeight: 1.65, padding: "10px 4px 14px" },
  storyActions: { display: "flex", gap: 8 },
  storyBack: { flex: 1, padding: "11px 12px", borderRadius: 13, border: "1px solid rgba(255,255,255,.11)", background: "rgba(255,255,255,.05)", color: "#ddd8e5", cursor: "pointer" },
  storyNext: { flex: 1, padding: "11px 12px", borderRadius: 13, border: "1px solid rgba(255,255,255,.14)", background: "linear-gradient(135deg,#8f63ef,#6b42cc)", color: "#fff", fontWeight: 750, cursor: "pointer" },
  storyVipNote: { marginTop: 12, padding: "10px 12px", borderRadius: 13, color: "#f1d37b", background: "rgba(242,196,90,.08)", border: "1px solid rgba(242,196,90,.2)", fontSize: 11.5, textAlign: "center" },

  storyNarrate: { width: "100%", padding: "11px 12px", borderRadius: 13, border: "1px solid rgba(242,196,90,.24)", background: "linear-gradient(145deg, rgba(242,196,90,.12), rgba(139,92,246,.08))", color: "#f1d37b", fontWeight: 750, cursor: "pointer", marginBottom: 9 },
};
